import argparse
import csv
import os
from pathlib import Path

import gymnasium as gym
from gymnasium import spaces
import matplotlib

os.environ.setdefault(
    "MPLCONFIGDIR",
    str(Path(__file__).resolve().parent / "output" / "matplotlib_cache"),
)
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pybullet as p
import torch
from stable_baselines3 import PPO, SAC
from stable_baselines3.common.callbacks import BaseCallback

from evaluate_baselines import (
    BaselineConveyorSortingEnv,
    EpisodeResult,
    is_in_decision_zone,
    is_in_firing_window,
    summarise_results,
    write_type_summary_csv,
    write_summary_csv,
)


BASE_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = BASE_DIR / "output" / "rl_final_training"
FIRE_WINDOW = 0.5
LOOKAHEAD_WINDOW = 1.2

# The environment uses a small MLP and many short simulation steps. Limiting
# PyTorch thread fan-out avoids large scheduling overhead on this workload.
torch.set_num_threads(1)
torch.set_num_interop_threads(1)


class RewardHistoryCallback(BaseCallback):
    """Record rolling mean training rewards for PPO/SAC comparison plots."""

    def __init__(self, log_interval=512, verbose=0):
        super().__init__(verbose)
        self.log_interval = log_interval
        self.steps = []
        self.mean_rewards = []
        self._recent_rewards = []

    def _on_step(self):
        rewards = self.locals.get("rewards")
        if rewards is not None:
            self._recent_rewards.extend(np.asarray(rewards).reshape(-1).tolist())
        if self.n_calls % self.log_interval == 0 and self._recent_rewards:
            self.steps.append(self.n_calls)
            self.mean_rewards.append(float(np.mean(self._recent_rewards[-self.log_interval:])))
        return True


def write_reward_history(callback, csv_path, plot_path):
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    with csv_path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(["timesteps", "rolling_mean_reward"])
        writer.writerows(zip(callback.steps, callback.mean_rewards))

    plt.figure(figsize=(8.5, 4.5))
    plt.plot(callback.steps, callback.mean_rewards, color="#2f6fbb", linewidth=1.8)
    plt.xlabel("Training timestep")
    plt.ylabel("Rolling mean reward")
    plt.title("Training reward history")
    plt.grid(alpha=0.25)
    plt.tight_layout()
    plt.savefig(plot_path, dpi=220)
    plt.close()


def write_action_heatmap(trace_rows, plot_path, title):
    if not trace_rows:
        return
    y_values = np.asarray([row["y_position"] for row in trace_rows], dtype=float)
    actions = np.asarray([row["action"] for row in trace_rows], dtype=int)
    bins = np.linspace(-8.0, 8.0, 25)
    heatmap = np.zeros((6, len(bins) - 1), dtype=int)
    y_indices = np.clip(np.digitize(y_values, bins) - 1, 0, len(bins) - 2)
    for action, y_index in zip(actions, y_indices):
        heatmap[int(np.clip(action, 0, 5)), y_index] += 1

    plt.figure(figsize=(8.5, 4.6))
    plt.imshow(
        heatmap,
        aspect="auto",
        origin="lower",
        extent=[bins[0], bins[-1], -0.5, 5.5],
        cmap="Blues",
    )
    plt.colorbar(label="Decision count")
    plt.yticks(range(6), ["Jet 1", "Jet 2", "Jet 3", "Jet 4", "Jet 5", "No action"])
    plt.xlabel("Tube longitudinal position")
    plt.ylabel("Selected action")
    plt.title(title)
    plt.tight_layout()
    plt.savefig(plot_path, dpi=220)
    plt.close()


def denormalise_tube_type(type_norm):
    tube_type = int(round(float(type_norm) * 2.0 + 2.0))
    return int(np.clip(tube_type, 0, 4))


def make_timing_obs(base_obs, env):
    y_pos = float(base_obs[0]) * 9.0
    tube_type = denormalise_tube_type(base_obs[1])
    target_y = float(env.jet_positions[tube_type])
    signed_distance = target_y - y_pos
    abs_distance = abs(signed_distance)
    in_window = 1.0 if abs_distance <= FIRE_WINDOW else 0.0
    lookahead = 1.0 if abs_distance <= LOOKAHEAD_WINDOW else 0.0
    return np.array(
        [
            np.clip(y_pos / 9.0, -1.0, 1.0),
            np.clip((tube_type - 2.0) / 2.0, -1.0, 1.0),
            np.clip(target_y / 9.0, -1.0, 1.0),
            np.clip(signed_distance / 9.0, -1.0, 1.0),
            in_window,
            lookahead,
        ],
        dtype=np.float32,
    )


def make_rich_timing_obs(base_obs, env):
    """Expose the kinematic variables needed to learn when to fire."""
    y_pos = float(base_obs[0]) * 9.0
    tube_type = denormalise_tube_type(base_obs[1])
    target_y = float(env.jet_positions[tube_type])
    signed_distance = target_y - y_pos
    active_tube = max(
        env.tubes,
        key=lambda tube: p.getBasePositionAndOrientation(tube["id"])[0][0],
    )
    position, _ = p.getBasePositionAndOrientation(active_tube["id"])
    velocity, _ = p.getBaseVelocity(active_tube["id"])
    fired = 1.0 if active_tube.get("fired", False) else 0.0
    return np.array(
        [
            np.clip(y_pos / 9.0, -1.0, 1.0),
            np.clip((tube_type - 2.0) / 2.0, -1.0, 1.0),
            np.clip(target_y / 9.0, -1.0, 1.0),
            np.clip(signed_distance / 9.0, -1.0, 1.0),
            np.clip(position[0] / 8.0, -1.0, 1.0),
            np.clip(velocity[0] / 3.0, -1.0, 1.0),
            np.clip(velocity[1] / 3.0, -1.0, 1.0),
            1.0 if abs(signed_distance) <= FIRE_WINDOW else 0.0,
            fired,
        ],
        dtype=np.float32,
    )


def timing_target_action(base_obs, env):
    tube_type = denormalise_tube_type(base_obs[1])
    y_pos = float(base_obs[0]) * 9.0
    target_y = float(env.jet_positions[tube_type])
    if abs(target_y - y_pos) <= LOOKAHEAD_WINDOW:
        return tube_type
    return 5


class FinalRLConveyorSortingEnv(gym.Env):
    metadata = {"render_modes": []}

    def __init__(self, algorithm="ppo", randomised=True, render=False):
        super().__init__()
        self.algorithm = algorithm.lower()
        self.base_env = BaselineConveyorSortingEnv(
            render=render,
            randomised=randomised,
            include_robot=False,
        )
        self.observation_space = spaces.Box(low=-1.0, high=1.0, shape=(9,), dtype=np.float32)
        if self.algorithm == "sac":
            self.action_space = spaces.Box(low=0.0, high=5.999, shape=(1,), dtype=np.float32)
        else:
            self.action_space = spaces.Discrete(6)

    def reset(self, seed=None, options=None):
        base_obs, info = self.base_env.reset(seed=seed)
        return make_rich_timing_obs(base_obs, self.base_env), info

    def _to_discrete_action(self, action):
        if self.algorithm == "sac":
            return int(np.clip(np.floor(float(np.asarray(action).reshape(-1)[0])), 0, 5))
        return int(action)

    def step(self, action):
        base_obs_before = self.base_env._get_obs()
        timing_obs_before = make_rich_timing_obs(base_obs_before, self.base_env)
        target_action = timing_target_action(base_obs_before, self.base_env)
        in_firing_window = is_in_firing_window(base_obs_before, self.base_env)
        discrete_action = self._to_discrete_action(action)
        base_obs, base_reward, terminated, truncated, info = self.base_env.step(discrete_action)

        correct_triggers = self.base_env.last_step_stats["correct_triggers"]
        wrong_triggers = self.base_env.last_step_stats["wrong_triggers"]
        false_actuations = self.base_env.last_step_stats["false_actuations"]

        reward = 30.0 * correct_triggers
        reward -= 25.0 * wrong_triggers
        reward -= 10.0 * false_actuations

        # Firing-window shaping keeps no-action neutral outside the jet window,
        # but makes missed responses costly once a tube is close enough to sort.
        if target_action != 5 and discrete_action == target_action:
            reward += 5.0 if in_firing_window else 2.0
        elif target_action != 5 and discrete_action == 5:
            reward -= 10.0 if in_firing_window else 3.0
        elif target_action != 5:
            reward -= 4.0 if in_firing_window else 1.0
        elif discrete_action != 5:
            reward -= 1.0

        info = dict(info)
        info["discrete_action"] = discrete_action
        info["target_action"] = target_action
        info["pre_action_distance"] = abs(float(timing_obs_before[3]))
        return make_rich_timing_obs(base_obs, self.base_env), float(reward), terminated, truncated, info

    def close(self):
        if getattr(self.base_env, "physics_client", None) is not None:
            try:
                p.disconnect(self.base_env.physics_client)
            except Exception:
                pass
            self.base_env.physics_client = None


def build_model(name, env, timesteps, seed):
    name = name.lower()
    if name == "ppo":
        return PPO(
            "MlpPolicy",
            env,
            learning_rate=3e-4,
            n_steps=2048,
            batch_size=128,
            gamma=0.995,
            seed=seed,
            verbose=1,
        )
    if name == "sac":
        return SAC(
            "MlpPolicy",
            env,
            learning_rate=3e-4,
            buffer_size=max(50000, timesteps * 2),
            learning_starts=min(3000, max(500, timesteps // 10)),
            batch_size=256,
            gamma=0.995,
            seed=seed,
            verbose=1,
        )
    raise ValueError(f"Unsupported algorithm: {name}")


def evaluate_model(model, algorithm, episodes, seed, randomised, trace_csv=None, heatmap_path=None):
    results = []
    trace_rows = []
    env = BaselineConveyorSortingEnv(
        render=False,
        randomised=randomised,
        include_robot=False,
    )
    for episode in range(episodes):
        np.random.seed(seed + episode)
        base_obs, _ = env.reset(seed=seed + episode)
        obs = make_rich_timing_obs(base_obs, env)
        terminated = False
        truncated = False
        total_reward = 0.0
        correct_commands = 0
        wrong_commands = 0
        no_actions = 0
        total_decisions = 0
        decision_zone_no_actions = 0
        decision_zone_decisions = 0
        firing_window_no_actions = 0
        firing_window_decisions = 0
        correct_triggers = 0
        wrong_triggers = 0
        false_actuations = 0

        while not (terminated or truncated):
            pre_action_obs = base_obs.copy()
            action, _ = model.predict(obs, deterministic=True)
            if algorithm == "sac":
                discrete_action = int(np.clip(np.floor(float(np.asarray(action).reshape(-1)[0])), 0, 5))
            else:
                discrete_action = int(action)

            true_type = denormalise_tube_type(base_obs[1])
            in_decision_zone = is_in_decision_zone(base_obs, env)
            in_firing_window = is_in_firing_window(base_obs, env)
            if discrete_action == 5:
                no_actions += 1
            elif discrete_action == true_type:
                correct_commands += 1
            else:
                wrong_commands += 1

            total_decisions += 1
            if in_decision_zone:
                decision_zone_decisions += 1
                if discrete_action == 5:
                    decision_zone_no_actions += 1
            if in_firing_window:
                firing_window_decisions += 1
                if discrete_action == 5:
                    firing_window_no_actions += 1
            target_action = timing_target_action(pre_action_obs, env)
            base_obs, reward, terminated, truncated, _ = env.step(discrete_action)
            obs = make_rich_timing_obs(base_obs, env)
            total_reward += float(reward)
            trace_rows.append(
                {
                    "controller": f"{algorithm.upper()} final",
                    "condition": "randomised" if randomised else "deterministic",
                    "seed": seed,
                    "episode": episode,
                    "step": total_decisions,
                    "tube_type": denormalise_tube_type(pre_action_obs[1]),
                    "y_position": float(pre_action_obs[0]) * 9.0,
                    "action": discrete_action,
                    "target_action": target_action,
                    "in_decision_zone": int(in_decision_zone),
                    "in_firing_window": int(in_firing_window),
                    "reward": float(reward),
                }
            )
            correct_triggers += env.last_step_stats["correct_triggers"]
            wrong_triggers += env.last_step_stats["wrong_triggers"]
            false_actuations += env.last_step_stats["false_actuations"]

        metrics = env.episode_metrics()
        results.append(
            EpisodeResult(
                controller=f"{algorithm.upper()} final",
                episode=episode,
                total_reward=total_reward,
                correct_commands=correct_commands,
                wrong_commands=wrong_commands,
                no_actions=no_actions,
                total_decisions=total_decisions,
                correct_triggers=correct_triggers,
                wrong_triggers=wrong_triggers,
                false_actuations=false_actuations,
                decision_zone_no_actions=decision_zone_no_actions,
                decision_zone_decisions=decision_zone_decisions,
                firing_window_no_actions=firing_window_no_actions,
                firing_window_decisions=firing_window_decisions,
                eligible_targets=metrics["eligible_targets"],
                successful_sorts=metrics["successful_sorts"],
                misfires=wrong_triggers + false_actuations,
                missed_targets=metrics["missed_targets"],
                type_metrics=metrics["type_metrics"],
            )
        )
    p.disconnect(env.physics_client)
    if trace_csv is not None:
        write_action_trace_csv(trace_rows, trace_csv)
    if heatmap_path is not None:
        write_action_heatmap(
            trace_rows,
            heatmap_path,
            f"{algorithm.upper()} state-action behaviour ({'randomised' if randomised else 'deterministic'})",
        )
    return results


def write_action_trace_csv(rows, csv_path):
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    with csv_path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(
            file,
            fieldnames=[
                "controller",
                "condition",
                "seed",
                "episode",
                "step",
                "tube_type",
                "y_position",
                "action",
                "target_action",
                "in_decision_zone",
                "in_firing_window",
                "reward",
            ],
        )
        writer.writeheader()
        writer.writerows(rows)


def write_episode_csv(results, csv_path):
    with csv_path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(
            [
                "controller",
                "episode",
                "total_reward",
                "correct_commands",
                "wrong_commands",
                "no_actions",
                "total_decisions",
                "command_accuracy",
                "wrong_command_rate",
                "no_action_rate",
                "decision_zone_no_actions",
                "decision_zone_decisions",
                "decision_zone_no_action_rate",
                "firing_window_no_actions",
                "firing_window_decisions",
                "firing_window_no_action_rate",
                "correct_triggers",
                "wrong_triggers",
                "false_actuations",
                "trigger_precision",
                "false_actuation_rate",
                "eligible_targets",
                "successful_sorts",
                "sorting_success_rate",
                "misfires",
                "misfire_rate",
                "missed_targets",
                "missed_target_rate",
            ]
        )
        for result in results:
            writer.writerow(
                [
                    result.controller,
                    result.episode,
                    f"{result.total_reward:.3f}",
                    result.correct_commands,
                    result.wrong_commands,
                    result.no_actions,
                    result.total_decisions,
                    f"{result.command_accuracy:.4f}",
                    f"{result.wrong_command_rate:.4f}",
                    f"{result.no_action_rate:.4f}",
                    result.decision_zone_no_actions,
                    result.decision_zone_decisions,
                    f"{result.decision_zone_no_action_rate:.4f}",
                    result.firing_window_no_actions,
                    result.firing_window_decisions,
                    f"{result.firing_window_no_action_rate:.4f}",
                    result.correct_triggers,
                    result.wrong_triggers,
                    result.false_actuations,
                    f"{result.trigger_precision:.4f}",
                    f"{result.false_actuation_rate:.4f}",
                    result.eligible_targets,
                    result.successful_sorts,
                    f"{result.sorting_success_rate:.4f}",
                    result.misfires,
                    f"{result.misfire_rate:.4f}",
                    result.missed_targets,
                    f"{result.missed_target_rate:.4f}",
                ]
            )


def plot_training_comparison(rows, output_path):
    labels = [f"{row['controller']}\n{row['condition']}" for row in rows]
    precision = [row["trigger_precision"] for row in rows]
    false_rate = [row["false_actuation"] for row in rows]
    no_action = [row["no_action"] for row in rows]
    x = np.arange(len(labels))
    width = 0.25
    fig, ax = plt.subplots(figsize=(11, 5.8))
    ax.bar(x - width, precision, width, label="Trigger precision")
    ax.bar(x, false_rate, width, label="False actuation rate")
    ax.bar(x + width, no_action, width, label="No action")
    ax.set_ylabel("Metric value (%)")
    ax.set_ylim(0, 105)
    ax.set_xticks(x)
    ax.set_xticklabels(labels)
    ax.legend(frameon=False, ncol=3, loc="upper center", bbox_to_anchor=(0.5, 1.12))
    ax.grid(axis="y", color="#dddddd", linewidth=0.8)
    fig.tight_layout()
    fig.savefig(output_path, dpi=220)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description="Train final PPO/SAC sorting controllers with timing-aware state.")
    parser.add_argument("--timesteps", type=int, default=100000)
    parser.add_argument("--episodes", type=int, default=20)
    parser.add_argument("--seed", type=int, default=71)
    parser.add_argument("--algorithms", nargs="+", default=["ppo", "sac"], choices=["ppo", "sac"])
    parser.add_argument("--output-dir", type=Path, default=OUTPUT_DIR)
    args = parser.parse_args()

    os.chdir(BASE_DIR)
    output_dir = args.output_dir if args.output_dir.is_absolute() else BASE_DIR / args.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    comparison_rows = []
    for algorithm in args.algorithms:
        print(f"\n=== Training final {algorithm.upper()} for {args.timesteps} timesteps ===")
        train_env = FinalRLConveyorSortingEnv(algorithm=algorithm, randomised=True, render=False)
        model = build_model(algorithm, train_env, args.timesteps, args.seed)
        model.learn(total_timesteps=args.timesteps)
        model_path = output_dir / f"{algorithm}_final_policy_{args.timesteps}_steps"
        model.save(model_path)
        train_env.close()

        for randomised in [False, True]:
            condition = "randomised" if randomised else "deterministic"
            results = evaluate_model(
                model=model,
                algorithm=algorithm,
                episodes=args.episodes,
                seed=args.seed,
                randomised=randomised,
            )
            episode_csv = output_dir / f"{algorithm}_final_episode_results_{condition}.csv"
            summary_csv = output_dir / f"{algorithm}_final_summary_{condition}.csv"
            write_episode_csv(results, episode_csv)
            summary = summarise_results(results)
            write_summary_csv(summary, summary_csv)
            values = summary[f"{algorithm.upper()} final"]
            row = {
                "controller": f"{algorithm.upper()} final",
                "condition": condition,
                "trigger_precision": values["mean_trigger_precision"] * 100.0,
                "false_actuation": values["mean_false_actuation_rate"] * 100.0,
                "no_action": values["mean_no_action_rate"] * 100.0,
                "reward": values["mean_reward"],
            }
            comparison_rows.append(row)
            print(
                f"{row['controller']} {condition}: "
                f"trigger_precision={row['trigger_precision']:.1f}% | "
                f"false_actuation={row['false_actuation']:.1f}% | "
                f"no_action={row['no_action']:.1f}% | "
                f"reward={row['reward']:.1f}"
            )

    plot_training_comparison(comparison_rows, output_dir / "final_rl_controller_summary.png")
    print(f"\nSaved final-policy outputs in: {output_dir}")


if __name__ == "__main__":
    main()
