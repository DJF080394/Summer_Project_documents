# Baseline Evaluation

This folder now contains a reproducible baseline evaluation for comparing non-learning controllers before making claims about reinforcement learning.

## Scripts

- `evaluate_baselines.py`
  - Runs three non-learning controllers:
    - `random`: randomly selects one of five jets or no action.
    - `class_rule`: maps the tube class directly to the corresponding jet.
    - `timing`: triggers the class-matched jet only when the tube is inside the calibrated firing window.
  - Outputs episode-level CSV, summary CSV, and a comparison chart.

- `capture_baseline_screenshots.py`
  - Captures PyBullet screenshots for the three baseline controllers.

## Commands

Deterministic baseline:

```bash
python evaluate_baselines.py --episodes 10
```

Randomised baseline:

```bash
python evaluate_baselines.py --episodes 10 --randomised
```

Screenshots:

```bash
python capture_baseline_screenshots.py
```

In this Codex environment, the runnable Python path was:

```bash
C:\Users\m5160\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe
```

## Output Files

Generated files are saved in:

```text
output/baseline_evaluation/
```

Important outputs:

- `baseline_summary_deterministic.csv`
- `baseline_summary_randomised.csv`
- `baseline_controller_comparison_deterministic.svg`
- `baseline_controller_comparison_randomised.svg`
- `screenshots/random_baseline_scene.png`
- `screenshots/class_rule_baseline_scene.png`
- `screenshots/timing_baseline_scene.png`

## Summary Results

Deterministic condition, 10 episodes:

| Controller | Mean reward | Trigger precision | False actuation rate | No-action rate |
|---|---:|---:|---:|---:|
| class_rule | 219.159 | 1.45% | 93.48% | 0.00% |
| random | 327.945 | 2.96% | 90.81% | 16.23% |
| timing | 355.587 | 17.50% | 22.50% | 98.55% |

Randomised condition, 10 episodes:

| Controller | Mean reward | Trigger precision | False actuation rate | No-action rate |
|---|---:|---:|---:|---:|
| class_rule | 311.736 | 1.74% | 93.04% | 0.00% |
| random | 271.174 | 1.90% | 91.18% | 16.23% |
| timing | 445.511 | 28.33% | 21.67% | 98.55% |

## Interpretation for Report

The class-rule controller always selects the class-matched jet, so it is logically correct at the class-mapping level. However, because it does not check whether the tube is inside the firing window, it produces many false actuations. This is an important engineering limitation of a pure rule-based mapping.

The timing controller is more conservative. It only triggers when the tube is close to the target jet, so its false-actuation rate is much lower and trigger precision is higher. However, its no-action rate is high, which means the firing window or timing model may be too strict and should be calibrated further.

These baseline results support the report argument: reinforcement learning should be compared against calibrated classical timing control, not only against random or simple class-rule baselines. A useful RL policy should preserve the low false-actuation behaviour of timing control while improving successful trigger frequency and robustness under randomised conditions.
