import os
import struct
import zlib
from pathlib import Path

import numpy as np
import pybullet as p

from evaluate_baselines import BaselineConveyorSortingEnv, POLICIES, OUTPUT_DIR


BASE_DIR = Path(__file__).resolve().parent
SCREENSHOT_DIR = OUTPUT_DIR / "screenshots"


def save_rgb_png(path, rgb):
    height, width, _ = rgb.shape
    raw_rows = []
    for y in range(height):
        raw_rows.append(b"\x00" + rgb[y].astype(np.uint8).tobytes())
    raw = b"".join(raw_rows)

    def chunk(tag, data):
        return (
            struct.pack(">I", len(data))
            + tag
            + data
            + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)
        )

    png = [
        b"\x89PNG\r\n\x1a\n",
        chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)),
        chunk(b"IDAT", zlib.compress(raw, level=6)),
        chunk(b"IEND", b""),
    ]
    path.write_bytes(b"".join(png))


def capture_camera(path):
    width = 1280
    height = 900
    view_matrix = p.computeViewMatrixFromYawPitchRoll(
        cameraTargetPosition=[-1.6, 0.0, 10.2],
        distance=11.0,
        yaw=42,
        pitch=-32,
        roll=0,
        upAxisIndex=2,
    )
    projection_matrix = p.computeProjectionMatrixFOV(
        fov=55,
        aspect=width / height,
        nearVal=0.1,
        farVal=100.0,
    )
    _, _, rgba, _, _ = p.getCameraImage(
        width,
        height,
        viewMatrix=view_matrix,
        projectionMatrix=projection_matrix,
        renderer=p.ER_BULLET_HARDWARE_OPENGL,
    )
    rgba = np.reshape(rgba, (height, width, 4))
    rgb = rgba[:, :, :3]
    save_rgb_png(path, rgb)


def add_scene_annotations(controller_name, action):
    p.addUserDebugText(
        f"Baseline: {controller_name}",
        [-5.0, -7.2, 14.5],
        textColorRGB=[0, 0, 0],
        textSize=1.2,
        lifeTime=0,
    )
    p.addUserDebugText(
        f"Selected action: {action}",
        [-5.0, -7.2, 13.8],
        textColorRGB=[0, 0, 0],
        textSize=1.0,
        lifeTime=0,
    )
    for index, y in enumerate([2.8 * i - 5.5 for i in range(5)]):
        p.addUserDebugLine([-4.1, y, 11.6], [-1.2, y, 11.6], [0, 0.7, 0], 2.0, 0)
        p.addUserDebugText(f"Jet {index}", [-4.6, y, 12.2], [0, 0.45, 0], 0.8, 0)


def capture_for_policy(controller_name, policy_fn):
    env = BaselineConveyorSortingEnv(render=False, randomised=False)
    obs, _ = env.reset(seed=12)

    selected_action = 5
    for _ in range(80):
        selected_action = int(policy_fn(obs, env))
        obs, _, terminated, truncated, _ = env.step(selected_action)
        if env.last_step_stats["correct_triggers"] or env.last_step_stats["wrong_triggers"]:
            break
        if terminated or truncated:
            break

    add_scene_annotations(controller_name, selected_action)
    for _ in range(30):
        p.stepSimulation()

    screenshot_path = SCREENSHOT_DIR / f"{controller_name}_baseline_scene.png"
    capture_camera(screenshot_path)
    p.disconnect(env.physics_client)
    return screenshot_path


def main():
    os.chdir(BASE_DIR)
    SCREENSHOT_DIR.mkdir(parents=True, exist_ok=True)
    paths = []
    for controller_name, policy_fn in POLICIES.items():
        print(f"Capturing {controller_name} baseline screenshot...")
        paths.append(capture_for_policy(controller_name, policy_fn))

    print("\nSaved screenshots:")
    for path in paths:
        print(path)


if __name__ == "__main__":
    main()
