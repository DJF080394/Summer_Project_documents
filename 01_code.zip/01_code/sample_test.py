import pybullet as p
import pybullet_data
import time
import numpy as np
import cv2
import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
from pathlib import Path
from ultralytics import YOLO

###############################################################################################################################################################
## Load in YOLO model after training ##
BASE_DIR = Path(__file__).resolve().parent
TRAINED_MODEL_CANDIDATES = sorted(
    (BASE_DIR / "runs" / "detect").glob("train*/weights/best.pt"),
    key=lambda path: path.stat().st_mtime,
    reverse=True
)
MODEL_CANDIDATES = [
    *TRAINED_MODEL_CANDIDATES,
    BASE_DIR / "yolo26n.pt",
    BASE_DIR / "yolov8n.pt",
    Path(r"C:\Users\jbuam\PycharmProjects\pybullet\runs\detect\train24\weights\best.pt"),
]
TUBE_CLASSES = {
    0: "polypropene tube 1",
    1: "polypropene tube 2",
    2: "polypropene centrifugal 1",
    3: "polypropene centrifugal 2",
    4: "lysis tube 1"
}
MODEL_PATH = next((path for path in MODEL_CANDIDATES if path.exists()), None)
if MODEL_PATH is not None:
    model = YOLO(str(MODEL_PATH))
    print(f"LOADED YOLO MODEL: {MODEL_PATH}")
    print(f"YOLO CLASS NAMES: {model.names}")
else:
    print("WARNING: No local YOLO weights found. AI will guess using default objects.")
    model = YOLO("yolov8n.pt")

###############################################################################################################################################################
## URDF Paths ##
CONVEYOR_1_URDF = r"./urdfs/conveyor_belt_draft.urdf"
CONVEYOR_2_URDF = r"./urdfs/conveyor_belt_with_hopper.urdf"
CONVEYOR_3_URDF = r"./urdfs/conveyor_belt_shortened.urdf"
CONVEYOR_4_URDF = r"./urdfs/conveyor_belt_project_2.urdf"
STAND_URDF = r"./urdfs/robot-stand.urdf" 
AIR_JET_URDF = r"./urdfs/air_jet.urdf"
BIN_URDF = r"./urdfs/bin.urdf"
BIN_FUNNEL_URDF = r"./urdfs/bin_funnel.urdf"
TUBE_URDF_PATHS = [
    r"./urdfs/tubes/polypropene-tube-1.urdf",
    r"./urdfs/tubes/polypropene-tube-2.urdf",
    r"./urdfs/tubes/polypropene-centrifugal-1.urdf",
    r"./urdfs/tubes/polypropene-centrifugal-2.urdf",
    r"./urdfs/tubes/lysis-tube-1.urdf"
    #r"C:\Users\jbuam\OneDrive\Documents\University\MECHANICAL ENGINEERING\Final year\Final Year Project (MEng)\capsule.urdf",
]

TUBE_BASES = [
    r"./urdfs/tubes/bases/polypropene-1-base.urdf",
    r"./urdfs/tubes/bases/polypropene-2-base.urdf",
    r"./urdfs/tubes/bases/polystyrene-1-base.urdf",
    r"./urdfs/tubes/bases/polystyrene-2-base.urdf",
    r"./urdfs/tubes/bases/lysis-base.urdf"
]
TUBE_CAPS = [
    r"./urdfs/tubes/caps/polypropene-1-cap.urdf",
    r"./urdfs/tubes/caps/polypropene-2-cap.urdf",
    r"./urdfs/tubes/caps/polystyrene-1-cap.urdf",
    r"./urdfs/tubes/caps/polystyrene-2-cap.urdf",
    r"./urdfs/tubes/caps/lysis-cap.urdf"
]
ur5_path = "./urdfs/ur5_robotiq_85.urdf" 

###############################################################################################################################################################
## Set up Simulation ##
p.connect(p.GUI)
p.setAdditionalSearchPath(pybullet_data.getDataPath())
p.setGravity(0, 0, -9.81)
p.loadURDF("plane.urdf")
air_jet_ori = p.getQuaternionFromEuler([0, 0, 1.57])
bin_ori = p.getQuaternionFromEuler([0, 0, 1.57])

'''
## Camera Adjustment ##
camera_distance = 1.1
camera_yaw = 90
camera_pitch = -45
camera_target = [0.5, 0, 0.6]
p.resetDebugVisualizerCamera(cameraDistance=camera_distance,
                                 cameraYaw=camera_yaw,
                                 cameraPitch=camera_pitch,
                                 cameraTargetPosition=camera_target)
'''

###############################################################################################################################################################
## Load in URDFs ##
try:
    #conveyor_id = p.loadURDF(CONVEYOR_1_URDF, basePosition=[0, 0, 7], useFixedBase=True)
    conveyor_id_4 = p.loadURDF(CONVEYOR_4_URDF, basePosition=[0, 0.7, 11], useFixedBase=True)
    p.changeVisualShape(conveyor_id_4, -1, rgbaColor=[0.627451, 0.627451, 0.627451, 1])
    conveyor_id_2 = p.loadURDF(CONVEYOR_2_URDF, basePosition=[0, -14, 7], useFixedBase=True)
    p.changeVisualShape(conveyor_id_2, -1, rgbaColor=[0.627451, 0.627451, 0.627451, 1])
    conveyor_id_3 = p.loadURDF(CONVEYOR_3_URDF, basePosition=[4, 0.7, 4.2*0.9], useFixedBase=True, globalScaling=0.9)
    p.changeVisualShape(conveyor_id_3, -1, rgbaColor=[0.627451, 0.627451, 0.627451, 1])
    robot_unscrewer = p.loadURDF(ur5_path, [4.8, 2.8*2-5.5 ,2], useFixedBase=True, globalScaling=6)
    cyl_col_id = p.createCollisionShape(p.GEOM_CYLINDER, 
                                radius=0.8, 
                                height=2)
    cyl_vis_id = p.createVisualShape(p.GEOM_CYLINDER, 
                             radius=0.8, 
                             length=2,
                             rgbaColor=[0.627451, 0.627451, 0.627451, 1])
    cyl_id = p.createMultiBody(baseMass=0, 
                             baseCollisionShapeIndex=cyl_col_id, 
                             baseVisualShapeIndex=cyl_vis_id,
                             basePosition=[4.8, 2.8*2-5.5, 1]) 
    box_stand_half_extents = [2.1, 1.35, 1]
    box_stand_col_id = p.createCollisionShape(p.GEOM_BOX, halfExtents=box_stand_half_extents)
    box_stand_vis_id = p.createVisualShape(p.GEOM_BOX, halfExtents=box_stand_half_extents, rgbaColor=[0.627451, 0.627451, 0.627451, 1])
    box_body_id = p.createMultiBody(baseMass=0, baseCollisionShapeIndex=box_stand_col_id, baseVisualShapeIndex=box_stand_vis_id, basePosition=[0, 9, 1])
    bin_instance = p.loadURDF(BIN_URDF, basePosition=[0, 9, 2], baseOrientation=bin_ori, useFixedBase=True)
    p.changeVisualShape(bin_instance, -1, rgbaColor=[0.627451, 0.627451, 0.627451, 1])
    for i in range(5):
        air_jet_instance = p.loadURDF(AIR_JET_URDF, basePosition=[-3.9, 2.8*i-4.8, 12.6], baseOrientation=air_jet_ori, useFixedBase=True)
        p.changeVisualShape(air_jet_instance, -1, rgbaColor=[0.627451, 0.627451, 0.627451, 1])
        binf_instance = p.loadURDF(BIN_FUNNEL_URDF, basePosition=[2.3, 2.8*i-5.5, 8.5], baseOrientation=bin_ori, useFixedBase=True)
        p.changeVisualShape(binf_instance, -1, rgbaColor=[0.627451, 0.627451, 0.627451, 1])
except:
    print("Conveyor URDF not found, using visual belt only.")

CAM_WIDTH, CAM_HEIGHT = 640, 640
DETECTION_WINDOW = "Detection Feed"
CLASS_CONFIDENCE_THRESHOLDS = {
    0: 0.18,
    1: 0.18,
    2: 0.16,
    3: 0.16,
    4: 0.20,
}
DETECTION_CONFIDENCE = min(CLASS_CONFIDENCE_THRESHOLDS.values())
DETECTION_IMGSZ = 640
USE_DETECTION_ROI = False
DETECTION_ROI = (0, 120, 640, 470)  # x1, y1, x2, y2: optional upper-conveyor crop
SPAWN_BELT_SPEED = 0.65
UPPER_BELT_SPEED = 1.10
LOWER_BELT_SPEED = 0.80
DROP_SPEED = -6.0
AIR_JET_X_SPEED = 2.40

CAM_TARGET = [-2.3, 0, 19]
view_matrix = p.computeViewMatrixFromYawPitchRoll(CAM_TARGET, 2.5, 90, -89.9, 0, 2)
proj_matrix = p.computeProjectionMatrixFOV(60, 1.0, 0.1, 100.0)
cv2.namedWindow(DETECTION_WINDOW, cv2.WINDOW_NORMAL)
cv2.resizeWindow(DETECTION_WINDOW, 720, 720)
tubes = []
step_count = 0
USE_YOLO_FOR_SORTING = False
DETECTION_INTERVAL = 60
DETECTION_SMOOTHING_WINDOW = 5
DETECTION_SMOOTHING_MIN_HITS = 3
DETECTION_STALE_STEPS = DETECTION_INTERVAL * 4


def project_world_to_pixel(world_pos):
    view_mat_np = np.array(view_matrix).reshape(4, 4, order='F')
    proj_mat_np = np.array(proj_matrix).reshape(4, 4, order='F')
    world_point = np.array([world_pos[0], world_pos[1], world_pos[2], 1.0])
    clip_point = proj_mat_np @ (view_mat_np @ world_point)
    if clip_point[3] == 0:
        return None
    ndc_point = clip_point[:3] / clip_point[3]
    x_px = (ndc_point[0] + 1.0) * 0.5 * CAM_WIDTH
    y_px = (1.0 - ndc_point[1]) * 0.5 * CAM_HEIGHT
    if x_px < 0 or x_px >= CAM_WIDTH or y_px < 0 or y_px >= CAM_HEIGHT:
        return None
    return np.array([x_px, y_px], dtype=np.float32)


def extract_yolo_detections(results, offset=(0, 0), keep_unknown=True):
    detections = []
    if not results or results[0].boxes is None:
        return detections
    offset_x, offset_y = offset
    for box in results[0].boxes:
        cls_id = int(box.cls[0])
        if not keep_unknown and cls_id not in TUBE_CLASSES:
            continue
        conf = float(box.conf[0])
        threshold = CLASS_CONFIDENCE_THRESHOLDS.get(cls_id, DETECTION_CONFIDENCE)
        if conf < threshold:
            continue
        xyxy = box.xyxy[0].cpu().numpy()
        xyxy[[0, 2]] += offset_x
        xyxy[[1, 3]] += offset_y
        center = np.array([(xyxy[0] + xyxy[2]) * 0.5, (xyxy[1] + xyxy[3]) * 0.5], dtype=np.float32)
        detections.append({
            "class_id": cls_id,
            "confidence": conf,
            "center": center,
            "xyxy": xyxy
        })
    return detections


def update_temporal_detection(tube, detection=None):
    history = tube.setdefault("det_history", [])
    if detection is not None:
        history.append({
            "class_id": detection["class_id"],
            "confidence": detection["confidence"],
            "step": step_count
        })

    recent_history = [
        item for item in history[-DETECTION_SMOOTHING_WINDOW:]
        if step_count - item["step"] <= DETECTION_STALE_STEPS
    ]
    tube["det_history"] = recent_history

    if not recent_history:
        tube["smoothed_type"] = None
        tube["smoothed_confidence"] = 0.0
        tube["smoothed_hits"] = 0
        return

    class_scores = {}
    class_counts = {}
    for item in recent_history:
        class_id = item["class_id"]
        class_scores[class_id] = class_scores.get(class_id, 0.0) + item["confidence"]
        class_counts[class_id] = class_counts.get(class_id, 0) + 1

    best_class = max(class_scores, key=class_scores.get)
    best_hits = class_counts[best_class]
    if best_hits >= DETECTION_SMOOTHING_MIN_HITS:
        tube["smoothed_type"] = best_class
        tube["smoothed_confidence"] = class_scores[best_class] / best_hits
        tube["smoothed_hits"] = best_hits
    else:
        tube["smoothed_type"] = None
        tube["smoothed_confidence"] = 0.0
        tube["smoothed_hits"] = best_hits


def assign_yolo_detections_to_tubes(detections, max_pixel_distance=120.0):
    tube_detections = [detection for detection in detections if detection["class_id"] in TUBE_CLASSES]
    used_detection_indexes = set()
    for tube in tubes:
        pos, _ = p.getBasePositionAndOrientation(tube['base_id'])
        projected_center = project_world_to_pixel(pos)
        if projected_center is None:
            update_temporal_detection(tube)
            continue

        best_index = None
        best_distance = max_pixel_distance
        for det_index, detection in enumerate(tube_detections):
            if det_index in used_detection_indexes:
                continue
            distance = np.linalg.norm(projected_center - detection["center"])
            if distance < best_distance:
                best_distance = distance
                best_index = det_index

        if best_index is not None:
            used_detection_indexes.add(best_index)
            detection = tube_detections[best_index]
            tube["detected_type"] = detection["class_id"]
            tube["det_confidence"] = detection["confidence"]
            tube["det_pixel_distance"] = float(best_distance)
            tube["last_detected_step"] = step_count
            update_temporal_detection(tube, detection)
        else:
            update_temporal_detection(tube)


def draw_smoothed_tube_states(frame_bgr):
    annotated = frame_bgr.copy()
    for tube in tubes:
        pos, _ = p.getBasePositionAndOrientation(tube['base_id'])
        projected_center = project_world_to_pixel(pos)
        if projected_center is None:
            continue

        x_px, y_px = projected_center.astype(int)
        smoothed_type = tube.get("smoothed_type")
        smoothed_confidence = tube.get("smoothed_confidence", 0.0)
        smoothed_hits = tube.get("smoothed_hits", 0)
        if smoothed_type is None:
            label = f"pending {smoothed_hits}/{DETECTION_SMOOTHING_MIN_HITS}"
            colour = (0, 165, 255)
        else:
            class_name = TUBE_CLASSES.get(smoothed_type, str(smoothed_type))
            label = f"stable: {class_name} {smoothed_confidence:.2f}"
            colour = (0, 255, 0)

        cv2.circle(annotated, (x_px, y_px), 5, colour, -1)
        cv2.putText(
            annotated,
            label,
            (x_px + 8, max(20, y_px - 8)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.5,
            colour,
            2
        )
    return annotated


def draw_yolo_detections(frame_bgr, detections):
    annotated = frame_bgr.copy()
    if USE_DETECTION_ROI:
        roi_x1, roi_y1, roi_x2, roi_y2 = DETECTION_ROI
        cv2.rectangle(annotated, (roi_x1, roi_y1), (roi_x2, roi_y2), (255, 255, 0), 1)
        cv2.putText(
            annotated,
            "YOLO ROI",
            (roi_x1 + 6, roi_y1 + 18),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            (255, 255, 0),
            2
        )
    for detection in detections:
        x1, y1, x2, y2 = detection["xyxy"].astype(int)
        class_name = TUBE_CLASSES.get(
            detection["class_id"],
            model.names.get(detection["class_id"], str(detection["class_id"]))
            if isinstance(model.names, dict)
            else str(detection["class_id"])
        )
        label = f"{class_name} {detection['confidence']:.2f}"
        colour = (0, 255, 255) if detection["class_id"] in TUBE_CLASSES else (0, 128, 255)
        cv2.rectangle(annotated, (x1, y1), (x2, y2), colour, 2)
        cv2.putText(
            annotated,
            label,
            (x1, max(20, y1 - 6)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            colour,
            2
        )
    cv2.putText(
        annotated,
        f"YOLO boxes: {len(detections)} | class-wise conf | stable {DETECTION_SMOOTHING_MIN_HITS}/{DETECTION_SMOOTHING_WINDOW}",
        (12, 28),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.7,
        (0, 255, 0),
        2
    )
    return annotated

###############################################################################################################################################################
## Spawn Tube Function ##
tube_constraints = {}
def spawn_tube():
    idx = np.random.randint(0, 5)
    start_pos = [-2, -13, 11]
    start_ori = p.getQuaternionFromEuler([1.5708, 0, np.random.uniform(0, 6.28)])
    base_id = p.loadURDF(TUBE_BASES[idx], start_pos, start_ori)
    cap_pos, cap_ori = p.multiplyTransforms(start_pos, start_ori, [0, 0, 0.5], [0, 0, 0, 1])
    cap_id = p.loadURDF(TUBE_CAPS[idx], cap_pos, cap_ori)
    cid = p.createConstraint(
        parentBodyUniqueId=base_id,
        parentLinkIndex=-1,
        childBodyUniqueId=cap_id,
        childLinkIndex=-1,
        jointType=p.JOINT_FIXED,
        jointAxis=[0, 0, 0],
        parentFramePosition=[0, 0, 0.5],
        childFramePosition=[0, 0, 0]
    )
    tube_name = TUBE_CLASSES[idx]
    tubes.append({
        'base_id': base_id,
        'cap_id': cap_id,
        'constraint_id': cid,
        'type': idx,
        'class': tube_name,
        'fired': False,
        'detected_type': None,
        'det_confidence': 0.0,
        'det_history': [],
        'smoothed_type': None,
        'smoothed_confidence': 0.0,
        'smoothed_hits': 0,
        'last_detected_step': None,
        'cap_grasped': False,
        'gripper_constraint_id': None
    })
    print(tubes[-1])
    '''
    t_id = p.loadURDF(TUBE_URDF_PATHS[idx], [-2, -13, 11], start_ori)
    p.changeDynamics(t_id, -1, mass=0.2, lateralFriction=2.0, angularDamping=0.9)
    tube_name = TUBE_CLASSES[idx]
    tubes.append({'id': t_id, 'type': idx, 'class': tube_name, 'fired': False})
    #print(tubes[-1])
    '''

###############################################################################################################################################################
## Guidelines (For Debugging Purposes) ##
corners = [
    [0, -13.5, 3],
    [0, -7, 3],
    [0, -7, 13.9],
    [0, -13.5, 13.9]
]
p.addUserDebugLine(corners[0], corners[1], [1, 0, 0], lineWidth=3) # Bottom
p.addUserDebugLine(corners[1], corners[2], [1, 0, 0], lineWidth=3) # Right
p.addUserDebugLine(corners[2], corners[3], [1, 0, 0], lineWidth=3) # Top
p.addUserDebugLine(corners[3], corners[0], [1, 0, 0], lineWidth=3) # Left
p.addUserDebugText("Tube Spawn Zone", [0, (-13.5+-7)/2, 13.9+1], [1,0,0], 1.5)

corners = [
    [1, -2, 5],
    [1, 2, 5],
    [7, 2, 5],
    [7, -2, 5]
]
p.addUserDebugLine(corners[0], corners[1], [0, 0, 1], lineWidth=3) # Bottom
p.addUserDebugLine(corners[1], corners[2], [0, 0, 1], lineWidth=3) # Right
p.addUserDebugLine(corners[2], corners[3], [0, 0, 1], lineWidth=3) # Top
p.addUserDebugLine(corners[3], corners[0], [0, 0, 1], lineWidth=3) # Left

'''
x_min = -3
x_max = -1
y_min = -8
y_max = 8
z_min = 12
z_max = 12.25
corners = [
    [x_min, y_min, z_min],  # 0
    [x_min, y_max, z_min],  # 1
    [x_min, y_max, z_max],  # 2
    [x_min, y_min, z_max],  # 3
    [x_max, y_min, z_min],  # 4
    [x_max, y_max, z_min],  # 5
    [x_max, y_max, z_max],  # 6
    [x_max, y_min, z_max],  # 7
]
# Front face (x_min)
p.addUserDebugLine(corners[0], corners[1], [1,0,0], 3)
p.addUserDebugLine(corners[1], corners[2], [1,0,0], 3)
p.addUserDebugLine(corners[2], corners[3], [1,0,0], 3)
p.addUserDebugLine(corners[3], corners[0], [1,0,0], 3)
# Back face (x_max)
p.addUserDebugLine(corners[4], corners[5], [1,0,0], 3)
p.addUserDebugLine(corners[5], corners[6], [1,0,0], 3)
p.addUserDebugLine(corners[6], corners[7], [1,0,0], 3)
p.addUserDebugLine(corners[7], corners[4], [1,0,0], 3)
# Connect front to back
p.addUserDebugLine(corners[0], corners[4], [1,0,0], 3)
p.addUserDebugLine(corners[1], corners[5], [1,0,0], 3)
p.addUserDebugLine(corners[2], corners[6], [1,0,0], 3)
p.addUserDebugLine(corners[3], corners[7], [1,0,0], 3)
'''

x_min, x_max, y_min, y_max, z_min, z_max = -1, 3, -8, 8, 4, 6
corners = [
    [x_min, y_min, z_min],
    [x_min, y_max, z_min],
    [x_min, y_max, z_max],
    [x_min, y_min, z_max],
    [x_max, y_min, z_min],
    [x_max, y_max, z_min],
    [x_max, y_max, z_max],
    [x_max, y_min, z_max],
]
# Front face (x_min)
p.addUserDebugLine(corners[0], corners[1], [1,0,0], 3)
p.addUserDebugLine(corners[1], corners[2], [1,0,0], 3)
p.addUserDebugLine(corners[2], corners[3], [1,0,0], 3)
p.addUserDebugLine(corners[3], corners[0], [1,0,0], 3)
# Back face (x_max)
p.addUserDebugLine(corners[4], corners[5], [1,0,0], 3)
p.addUserDebugLine(corners[5], corners[6], [1,0,0], 3)
p.addUserDebugLine(corners[6], corners[7], [1,0,0], 3)
p.addUserDebugLine(corners[7], corners[4], [1,0,0], 3)
# Connect front to back
p.addUserDebugLine(corners[0], corners[4], [1,0,0], 3)
p.addUserDebugLine(corners[1], corners[5], [1,0,0], 3)
p.addUserDebugLine(corners[2], corners[6], [1,0,0], 3)
p.addUserDebugLine(corners[3], corners[7], [1,0,0], 3)



###############################################################################################################################################################
## Main Loop ##
try:
    air_jet_boxes_drawn = False
    spawn_tube()
    while True:
        p.stepSimulation()
        step_count += 1
              
        
        if step_count % 1000 == 0:
            spawn_tube()

        if step_count % DETECTION_INTERVAL == 0:
            img_data = p.getCameraImage(CAM_WIDTH, CAM_HEIGHT, view_matrix, proj_matrix, shadow=0, renderer=p.ER_BULLET_HARDWARE_OPENGL)
            rgb = np.reshape(img_data[2], (CAM_HEIGHT, CAM_WIDTH, 4))[:, :, :3]
            rgb = np.ascontiguousarray(rgb, dtype=np.uint8)
            bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
            if USE_DETECTION_ROI:
                roi_x1, roi_y1, roi_x2, roi_y2 = DETECTION_ROI
                model_frame = bgr[roi_y1:roi_y2, roi_x1:roi_x2]
                offset = (roi_x1, roi_y1)
            else:
                model_frame = bgr
                offset = (0, 0)
            results = model.predict(model_frame, conf=DETECTION_CONFIDENCE, verbose=False, imgsz=DETECTION_IMGSZ)
            detections = extract_yolo_detections(results, offset=offset)
            assign_yolo_detections_to_tubes(detections)
            tube_detection_count = sum(1 for detection in detections if detection["class_id"] in TUBE_CLASSES)
            stable_tube_count = sum(1 for tube in tubes if tube.get("smoothed_type") is not None)
            print(
                f"YOLO detections: {len(detections)} total, "
                f"{tube_detection_count} tube-class, {stable_tube_count} stable tubes"
            )

            annotated_frame = draw_yolo_detections(bgr, detections)
            annotated_frame = draw_smoothed_tube_states(annotated_frame)
            cv2.imshow(DETECTION_WINDOW, annotated_frame)
            cv2.waitKey(1)

        # Movement Logic
        robot_should_move = False
        for tube in tubes[:]:
            pos, _ = p.getBasePositionAndOrientation(tube['base_id'])
            cap_pos, _ = p.getBasePositionAndOrientation(tube['cap_id'])
            if -13.5 < pos[1] < -7 and 3 < pos[2] < 13.9:
                p.resetBaseVelocity(tube['base_id'], [0, SPAWN_BELT_SPEED, 0.25], [0, 0, 0])
            if -8.0 < pos[1] < 8.0 and 12 < pos[2] < 12.25 and -3 < pos[0] < -1:
                p.resetBaseVelocity(tube['base_id'], [0, UPPER_BELT_SPEED, 0], [0, 0, 0])
            if pos[1] > 9.0:
                p.removeBody(tube['base_id'])
                p.removeBody(tube['cap_id'])
                tubes.remove(tube)
            if -3 < pos[0] < 3 and 0 < pos[2] < 10:
                upright_ori = p.getQuaternionFromEuler([0, 0, 0])
                p.resetBasePositionAndOrientation(tube['base_id'], [2, pos[1], pos[2]], upright_ori)
                p.resetBaseVelocity(tube['base_id'], linearVelocity=[0, 0, DROP_SPEED], angularVelocity=[0, 0, 0])
            if -1.0 < pos[0] < 3.0 and -8.0 < pos[1] < 8.0 and 4 < pos[2] < 5.4:
                p.resetBaseVelocity(tube['base_id'], [0, LOWER_BELT_SPEED, 0], [0, 0, 0])
            if 1.0 < pos[0] < 7.0 and -2.0 < pos[1] < 2.0 and 4 < pos[2] < 6:
                robot_should_move = True
                break
        if robot_should_move:
            target_angles = [0, 0, 0, -1.2, -2.5, -3, -2.5] # in radians
            cap_pos, _ = p.getBasePositionAndOrientation(tube['cap_id'])
            for i, angle in enumerate(target_angles):
                p.setJointMotorControl2(
                    bodyIndex=robot_unscrewer,
                    jointIndex=i,
                    controlMode=p.POSITION_CONTROL,
                    targetPosition=angle,
                    force=40000,
                    maxVelocity=6
                )
            gripper_state = p.getLinkState(robot_unscrewer, 7)
            gripper_pos = gripper_state[0]
            gripper_ori = gripper_state[1]
            cap_pos, cap_ori = p.getBasePositionAndOrientation(tube['cap_id'])
            inv_gripper_pos, inv_gripper_ori = p.invertTransform(gripper_pos, gripper_ori)
            local_cap_pos, local_cap_ori = p.multiplyTransforms(inv_gripper_pos, inv_gripper_ori, cap_pos, cap_ori)
            distance = np.linalg.norm(np.array(gripper_pos) - np.array(cap_pos))
            if distance < 0.9 and not tube.get('cap_grasped', False):
                p.removeConstraint(tube['constraint_id'])
                gripper_constraint_id = p.createConstraint(
                    parentBodyUniqueId=robot_unscrewer,
                    parentLinkIndex=7,
                    childBodyUniqueId=tube['cap_id'],
                    childLinkIndex=-1,
                    jointType=p.JOINT_FIXED,
                    jointAxis=[0, 0, 0],
                    parentFramePosition=[-0.2, 0, 0],
                    parentFrameOrientation=[0, 0, 0, 1],
                    childFramePosition=[0, 0, 0]
                )
                tube['cap_grasped'] = True
                tube['gripper_constraint_id'] = gripper_constraint_id
        else:
            target_angles = [0, 0, 0, 0, 0, 0, 0]         
            for i, angle in enumerate(target_angles):
                p.setJointMotorControl2(
                    bodyIndex=robot_unscrewer,
                    jointIndex=i,
                    controlMode=p.POSITION_CONTROL,
                    targetPosition=angle,
                    force=40000,
                    maxVelocity=4
                )            
        
        # Air Jet Logic
        jet_x_source = -3.9
        jet_z_level = 12.6
        jet_positions = [2.8*i-5.5+0.7 for i in range(5)]
        if not air_jet_boxes_drawn:
            for y_pos in jet_positions:
                min_pt = [-4.0, y_pos - 0.3, jet_z_level - 0.8]
                max_pt = [-1.0, y_pos + 0.3, jet_z_level + 0.8]
                def draw_box(low, high, color):
                    points = [
                        [low[0], low[1], low[2]], [high[0], low[1], low[2]],
                        [high[0], high[1], low[2]], [low[0], high[1], low[2]],
                        [low[0], low[1], high[2]], [high[0], low[1], high[2]],
                        [high[0], high[1], high[2]], [low[0], high[1], high[2]]
                    ]
                    lines = [
                        [0,1], [1,2], [2,3], [3,0], # Bottom
                        [4,5], [5,6], [6,7], [7,4], # Top
                        [0,4], [1,5], [2,6], [3,7]
                    ]
                    for start, end in lines:
                        p.addUserDebugLine(points[start], points[end], color, lineWidth=1, lifeTime=0)

                draw_box(min_pt, max_pt, [0, 1, 0])
            air_jet_boxes_drawn = True
        for tube in tubes[:]:
            pos, _ = p.getBasePositionAndOrientation(tube['base_id'])
            true_tube_type = tube['type']
            detected_tube_type = tube.get('detected_type')
            detection_confidence = tube.get('det_confidence', 0.0)
            smoothed_tube_type = tube.get('smoothed_type')
            smoothed_confidence = tube.get('smoothed_confidence', 0.0)
            use_yolo_prediction = USE_YOLO_FOR_SORTING and smoothed_tube_type is not None
            control_tube_type = smoothed_tube_type if use_yolo_prediction else true_tube_type
            control_source = "YOLO" if use_yolo_prediction else "GROUND_TRUTH"
            for jet_index, target_jet_y in enumerate(jet_positions):
                y_hit = abs(pos[1] - target_jet_y) < 0.5
                x_hit = -5.0 < pos[0] < -0
                z_hit = 11.0 < pos[2] < 14.0
                
                if y_hit and x_hit and z_hit:
                    if control_tube_type == jet_index:                       
                        if 12 < pos[2] < 12.5:
                            tube['fired'] = True
                            p.resetBaseVelocity(tube['base_id'], linearVelocity=[AIR_JET_X_SPEED, 0, 1.2])
                            #p.applyExternalForce(tube['id'], -1,
                            #                       forceObj=[10, -6, 20],
                            #                       posObj=pos,
                            #                       flags=p.WORLD_FRAME
                            #)
                                                 
                        print(
                            f"JET {jet_index} TRIGGERED BY {control_source}: "
                            f"predicted={TUBE_CLASSES.get(detected_tube_type, detected_tube_type)} "
                            f"conf={detection_confidence:.2f} "
                            f"stable={TUBE_CLASSES.get(smoothed_tube_type, smoothed_tube_type)} "
                            f"stable_conf={smoothed_confidence:.2f} "
                            f"ground_truth={TUBE_CLASSES.get(true_tube_type, true_tube_type)}"
                        )
                        tube['fired'] = True
                        p.addUserDebugLine([jet_x_source, target_jet_y, jet_z_level], 
                                           [pos[0], pos[1], pos[2]], 
                                           lineColorRGB=[1, 0, 0], 
                                           lineWidth=2, 
                                           lifeTime=0.1)
                        break
                
                                   
        time.sleep(1. / 240.)
except KeyboardInterrupt:
    p.disconnect()
    cv2.destroyAllWindows()
