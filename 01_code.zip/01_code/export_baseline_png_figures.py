import csv
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


BASE_DIR = Path(__file__).resolve().parent
OUTPUT_DIRS = [
    BASE_DIR / "output of baseline" / "baseline_evaluation",
    BASE_DIR / "output" / "baseline_evaluation",
]
REPORT_FIGURE_DIR = Path(r"E:\Google\SummerProject\Final_Report_Jianfeng\figures")


def find_output_dir():
    for output_dir in OUTPUT_DIRS:
        if (output_dir / "baseline_summary_deterministic.csv").exists():
            return output_dir
    raise FileNotFoundError("No baseline summary CSV files were found.")


def read_summary(path):
    rows = []
    with path.open(newline="", encoding="utf-8") as file:
        for row in csv.DictReader(file):
            rows.append(
                {
                    "controller": row["controller"],
                    "trigger_precision": float(row["mean_trigger_precision"]) * 100.0,
                    "false_actuation": float(row["mean_false_actuation_rate"]) * 100.0,
                    "no_action": float(row["mean_no_action_rate"]) * 100.0,
                }
            )
    return rows


def font(size, bold=False):
    candidates = [
        "C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf",
        "C:/Windows/Fonts/calibrib.ttf" if bold else "C:/Windows/Fonts/calibri.ttf",
    ]
    for candidate in candidates:
        if Path(candidate).exists():
            return ImageFont.truetype(candidate, size)
    return ImageFont.load_default()


def draw_baseline_chart(rows, condition, output_path):
    width = 1800
    height = 1240
    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image)

    title_font = font(42, bold=True)
    subtitle_font = font(24)
    label_font = font(27, bold=True)
    small_font = font(22)
    axis_font = font(20)

    colors = {
        "trigger_precision": (47, 111, 187),
        "false_actuation": (201, 79, 79),
        "no_action": (109, 159, 69),
    }
    labels = [
        ("trigger_precision", "Trigger precision"),
        ("false_actuation", "False actuation rate"),
        ("no_action", "No action"),
    ]

    title = "Baseline controller comparison"
    subtitle = f"Condition: {condition}; values are mean percentages over 10 episodes"
    draw.text((width / 2, 58), title, anchor="mm", fill=(20, 20, 20), font=title_font)
    draw.text((width / 2, 105), subtitle, anchor="mm", fill=(85, 85, 85), font=subtitle_font)

    legend_x = 290
    for index, (key, label) in enumerate(labels):
        x = legend_x + index * 420
        y = 160
        draw.rounded_rectangle((x, y, x + 26, y + 26), radius=4, fill=colors[key])
        draw.text((x + 42, y + 13), label, anchor="lm", fill=(30, 30, 30), font=small_font)

    chart_left = 300
    chart_right = 1660
    chart_top = 250
    axis_y = 950
    chart_width = chart_right - chart_left
    row_gap = 220
    bar_height = 32
    bar_gap = 23

    for tick in range(0, 101, 20):
        x = chart_left + chart_width * tick / 100.0
        draw.line((x, chart_top - 25, x, axis_y), fill=(225, 229, 235), width=2)
        draw.text((x, axis_y + 34), str(tick), anchor="mm", fill=(80, 80, 80), font=axis_font)
    draw.line((chart_left, axis_y, chart_right, axis_y), fill=(60, 65, 75), width=2)
    draw.text(((chart_left + chart_right) / 2, axis_y + 82), "Metric value (%)", anchor="mm", fill=(80, 80, 80), font=axis_font)

    for row_index, row in enumerate(rows):
        group_y = chart_top + row_index * row_gap
        draw.text((chart_left - 35, group_y + 65), row["controller"], anchor="rm", fill=(30, 30, 30), font=label_font)

        for metric_index, (key, _) in enumerate(labels):
            value = row[key]
            y = group_y + metric_index * (bar_height + bar_gap)
            bar_width = max(2, chart_width * value / 100.0)
            x2 = chart_left + bar_width
            draw.rounded_rectangle((chart_left, y, x2, y + bar_height), radius=7, fill=colors[key])

            text = f"{value:.1f}%"
            value_x = x2 + 14
            anchor = "lm"
            fill = (30, 30, 30)
            if value_x > chart_right - 80:
                value_x = x2 - 14
                anchor = "rm"
                fill = (255, 255, 255)
            draw.text((value_x, y + bar_height / 2), text, anchor=anchor, fill=fill, font=small_font)

    note = "Note: a lower false actuation rate is better; timing control is conservative, so its no-action rate is high."
    draw.text((chart_left, height - 72), note, anchor="lm", fill=(90, 90, 90), font=small_font)

    image.save(output_path, "PNG", optimize=True)


def main():
    output_dir = find_output_dir()
    REPORT_FIGURE_DIR.mkdir(parents=True, exist_ok=True)

    generated = []
    for condition in ["deterministic", "randomised"]:
        rows = read_summary(output_dir / f"baseline_summary_{condition}.csv")
        output_path = REPORT_FIGURE_DIR / f"baseline_controller_comparison_{condition}.png"
        draw_baseline_chart(rows, condition, output_path)
        generated.append(output_path)

    print("Generated PNG figures:")
    for path in generated:
        print(path)


if __name__ == "__main__":
    main()
