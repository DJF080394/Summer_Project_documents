"""Re-evaluate saved formal PPO/SAC policies with system-level sorting metrics."""

from pathlib import Path

from stable_baselines3 import PPO, SAC

from evaluate_baselines import (
    evaluate_policy,
    summarise_results,
    timing_policy,
    write_episode_csv,
    write_summary_csv,
    write_type_summary_csv,
)
from train_final_rl_controllers import (
    evaluate_model,
)


BASE_DIR = Path(__file__).resolve().parent
FORMAL_DIR = BASE_DIR / "output" / "script_training"
SEEDS = (71, 83, 97)
EPISODES = 20


def run():
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--seeds", nargs="+", type=int, default=list(SEEDS))
    parser.add_argument("--episodes", type=int, default=EPISODES)
    args = parser.parse_args()

    aggregate_rows = []
    for seed in args.seeds:
        for algorithm, model_cls in (("ppo", PPO), ("sac", SAC)):
            model_path = FORMAL_DIR / f"seed_{seed}" / algorithm / f"{algorithm}_policy_30000_steps_seed_{seed}.zip"
            output_dir = FORMAL_DIR / f"seed_{seed}" / algorithm
            model = model_cls.load(model_path)
            for randomised in (False, True):
                condition = "randomised" if randomised else "deterministic"
                results = evaluate_model(
                    model=model,
                    algorithm=algorithm,
                    episodes=args.episodes,
                    seed=seed,
                    randomised=randomised,
                    trace_csv=output_dir / f"{algorithm}_action_trace_{condition}_seed_{seed}.csv",
                    heatmap_path=output_dir / f"{algorithm}_state_action_{condition}_seed_{seed}.png",
                )
                write_episode_csv(
                    results,
                    output_dir / f"{algorithm}_episode_results_{condition}_seed_{seed}.csv",
                )
                write_summary_csv(
                    summarise_results(results),
                    output_dir / f"{algorithm}_summary_{condition}_seed_{seed}.csv",
                )
                write_type_summary_csv(
                    results,
                    output_dir / f"{algorithm}_type_summary_{condition}_seed_{seed}.csv",
                )
                values = summarise_results(results)[f"{algorithm.upper()} final"]
                aggregate_rows.append(
                    {
                        "controller": f"{algorithm.upper()} final",
                        "condition": condition,
                        "seed": seed,
                        **values,
                    }
                )

        # The baseline is evaluated on the same episode seeds for comparison.
        baseline_dir = FORMAL_DIR / f"seed_{seed}" / "timing_baseline"
        baseline_dir.mkdir(parents=True, exist_ok=True)
        for randomised in (False, True):
            condition = "randomised" if randomised else "deterministic"
            results = evaluate_policy(
                "Timing baseline",
                timing_policy,
                args.episodes,
                seed,
                randomised,
                render=False,
                include_robot=False,
            )
            write_episode_csv(
                results,
                baseline_dir / f"timing_episode_results_{condition}_seed_{seed}.csv",
            )
            write_summary_csv(
                summarise_results(results),
                baseline_dir / f"timing_summary_{condition}_seed_{seed}.csv",
            )
            write_type_summary_csv(
                results,
                baseline_dir / f"timing_type_summary_{condition}_seed_{seed}.csv",
            )
            values = summarise_results(results)["Timing baseline"]
            aggregate_rows.append(
                {
                    "controller": "Timing baseline",
                    "condition": condition,
                    "seed": seed,
                    **values,
                }
            )

    fieldnames = [
        "controller",
        "condition",
        "seed",
        "mean_eligible_targets",
        "mean_decision_zone_no_actions",
        "mean_decision_zone_decisions",
        "mean_decision_zone_no_action_rate",
        "mean_firing_window_no_actions",
        "mean_firing_window_decisions",
        "mean_firing_window_no_action_rate",
        "mean_successful_sorts",
        "mean_sorting_success_rate",
        "mean_misfires",
        "mean_misfire_rate",
        "mean_missed_targets",
        "mean_missed_target_rate",
        "mean_reward",
        "std_reward",
    ]
    import csv

    with (FORMAL_DIR / "system_metrics_by_seed.csv").open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        for row in aggregate_rows:
            writer.writerow({key: row.get(key, "") for key in fieldnames})


if __name__ == "__main__":
    run()
