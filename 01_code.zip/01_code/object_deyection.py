import os
from pathlib import Path

import cv2
import numpy as np
import pybullet as p
import pybullet_data


BASE_DIR = Path(__file__).resolve().parent

CONVEYOR_URDF = BASE_DIR / "urdfs" / "conveyor_belt_with_hopper.urdf"
TUBE_BASES = [
    BASE_DIR / "urdfs" / "tubes" / "bases" / "polypropene-1-base.urdf",
    BASE_DIR / "urdfs" / "tubes" / "bases" / "polypropene-2-base.urdf",
    BASE_DIR / "urdfs" / "tubes" / "bases" / "polystyrene-1-base.urdf",
    BASE_DIR / "urdfs" / "tubes" / "bases" / "polystyrene-2-base.urdf",
    BASE_DIR / "urdfs" / "tubes" / "bases" / "lysis-base.urdf",
]
TUBE_CAPS = [
    BASE_DIR / "urdfs" / "tubes" / "caps" / "polypropene-1-cap.urdf",
    BASE_DIR / "urdfs" / "tubes" / "caps" / "polypropene-2-cap.urdf",
    BASE_DIR / "urdfs" / "tubes" / "caps" / "polystyrene-1-cap.urdf",
    BASE_DIR / "urdfs" / "tubes" / "caps" / "polystyrene-2-cap.urdf",
    BASE_DIR / "urdfs" / "tubes" / "caps" / "lysis-cap.urdf",
]
CLASS_NAMES = [
    "polypropene_tube_1",
    "polypropene_tube_2",
    "polypropene_centrifugal_1",
    "polypropene_centrifugal_2",
    "lysis_tube_1",
]

CAM_WIDTH, CAM_HEIGHT = 640, 640
CAMERA_TARGET = [-2.0, -13.0, 11.0]
CAMERA_DISTANCE = 3.0


def make_yolo_dirs(dataset_path):
    for sub in ["images/train", "images/val", "labels/train", "labels/val"]:
        (dataset_path / sub).mkdir(parents=True, exist_ok=True)


def get_camera_matrices():
    yaw = np.random.uniform(82.0, 98.0)
    pitch = np.random.uniform(-89.9, -84.0)
    roll = np.random.uniform(-2.0, 2.0)
    distance = CAMERA_DISTANCE + np.random.uniform(-0.25, 0.35)
    view_matrix = p.computeViewMatrixFromYawPitchRoll(
        CAMERA_TARGET,
        distance,
        yaw,
        pitch,
        roll,
        2,
    )
    proj_matrix = p.computeProjectionMatrixFOV(
        np.random.uniform(55.0, 68.0),
        CAM_WIDTH / CAM_HEIGHT,
        0.1,
        100.0,
    )
    return view_matrix, proj_matrix


def setup_scene():
    p.resetSimulation()
    p.setGravity(0, 0, -9.81)
    p.loadURDF("plane.urdf")
    p.loadURDF(str(CONVEYOR_URDF), basePosition=[0, -14, 7], useFixedBase=True)


def random_rgba(base_colour):
    jitter = np.random.uniform(-0.12, 0.12, size=3)
    colour = np.clip(np.array(base_colour[:3]) + jitter, 0.15, 0.95)
    alpha = np.random.uniform(0.82, 1.0)
    return [float(colour[0]), float(colour[1]), float(colour[2]), float(alpha)]


def spawn_tube_assembly(class_id):
    start_pos = [
        -2.0 + np.random.uniform(-0.35, 0.35),
        -13.0 + np.random.uniform(-0.55, 0.55),
        11.0 + np.random.uniform(-0.18, 0.18),
    ]
    start_ori = p.getQuaternionFromEuler([
        np.random.uniform(1.25, 1.9),
        np.random.uniform(-0.22, 0.22),
        np.random.uniform(0.0, 6.28),
    ])
    base_id = p.loadURDF(str(TUBE_BASES[class_id]), start_pos, start_ori)
    cap_pos, cap_ori = p.multiplyTransforms(start_pos, start_ori, [0, 0, 0.5], [0, 0, 0, 1])
    cap_id = p.loadURDF(str(TUBE_CAPS[class_id]), cap_pos, cap_ori)
    constraint_id = p.createConstraint(
        parentBodyUniqueId=base_id,
        parentLinkIndex=-1,
        childBodyUniqueId=cap_id,
        childLinkIndex=-1,
        jointType=p.JOINT_FIXED,
        jointAxis=[0, 0, 0],
        parentFramePosition=[0, 0, 0.5],
        childFramePosition=[0, 0, 0],
    )

    mass = np.random.uniform(0.13, 0.30)
    friction = np.random.uniform(1.0, 3.0)
    damping = np.random.uniform(0.45, 1.25)
    for body_id in [base_id, cap_id]:
        p.changeDynamics(body_id, -1, mass=mass, lateralFriction=friction, angularDamping=damping)

    base_palette = [
        [0.72, 0.74, 0.78],
        [0.82, 0.80, 0.74],
        [0.62, 0.72, 0.86],
        [0.80, 0.68, 0.72],
        [0.70, 0.82, 0.76],
    ]
    cap_palette = [
        [0.18, 0.33, 0.86],
        [0.86, 0.22, 0.18],
        [0.30, 0.66, 0.28],
        [0.90, 0.72, 0.18],
        [0.50, 0.24, 0.74],
    ]
    p.changeVisualShape(base_id, -1, rgbaColor=random_rgba(base_palette[class_id]))
    p.changeVisualShape(cap_id, -1, rgbaColor=random_rgba(cap_palette[class_id]))
    return base_id, cap_id, constraint_id


def remove_tube_assembly(base_id, cap_id, constraint_id):
    try:
        p.removeConstraint(constraint_id)
    except Exception:
        pass
    p.removeBody(base_id)
    p.removeBody(cap_id)


def project_world_to_pixel(world_pos, view_matrix, proj_matrix):
    view_mat_np = np.array(view_matrix).reshape(4, 4, order="F")
    proj_mat_np = np.array(proj_matrix).reshape(4, 4, order="F")
    world_point = np.array([world_pos[0], world_pos[1], world_pos[2], 1.0])
    clip_point = proj_mat_np @ (view_mat_np @ world_point)
    if abs(clip_point[3]) < 1e-8:
        return None
    ndc_point = clip_point[:3] / clip_point[3]
    if ndc_point[2] < -1.0 or ndc_point[2] > 1.0:
        return None
    x_px = (ndc_point[0] + 1.0) * 0.5 * CAM_WIDTH
    y_px = (1.0 - ndc_point[1]) * 0.5 * CAM_HEIGHT
    return np.array([x_px, y_px], dtype=np.float32)


def aabb_corners(body_id):
    min_point, max_point = p.getAABB(body_id)
    xs = [min_point[0], max_point[0]]
    ys = [min_point[1], max_point[1]]
    zs = [min_point[2], max_point[2]]
    return [[x, y, z] for x in xs for y in ys for z in zs]


def get_projected_yolo_annotation(body_ids, class_id, view_matrix, proj_matrix):
    projected_points = []
    for body_id in body_ids:
        for corner in aabb_corners(body_id):
            pixel = project_world_to_pixel(corner, view_matrix, proj_matrix)
            if pixel is not None:
                projected_points.append(pixel)

    if len(projected_points) < 2:
        return None

    points = np.array(projected_points)
    x_min = float(np.clip(points[:, 0].min(), 0, CAM_WIDTH - 1))
    x_max = float(np.clip(points[:, 0].max(), 0, CAM_WIDTH - 1))
    y_min = float(np.clip(points[:, 1].min(), 0, CAM_HEIGHT - 1))
    y_max = float(np.clip(points[:, 1].max(), 0, CAM_HEIGHT - 1))

    box_w = x_max - x_min
    box_h = y_max - y_min
    if box_w < 6 or box_h < 6:
        return None

    x_center = ((x_min + x_max) * 0.5) / CAM_WIDTH
    y_center = ((y_min + y_max) * 0.5) / CAM_HEIGHT
    w_norm = box_w / CAM_WIDTH
    h_norm = box_h / CAM_HEIGHT
    return f"{class_id} {x_center:.6f} {y_center:.6f} {w_norm:.6f} {h_norm:.6f}"


def run_data_collection():
    dataset_name = input("Please enter the name of the dataset folder: ").strip() or "tube1_improved"
    dataset_path = BASE_DIR / dataset_name
    make_yolo_dirs(dataset_path)

    if not CONVEYOR_URDF.exists():
        raise FileNotFoundError(f"Conveyor URDF not found: {CONVEYOR_URDF}")
    for urdf_path in [*TUBE_BASES, *TUBE_CAPS]:
        if not urdf_path.exists():
            raise FileNotFoundError(f"Tube URDF not found: {urdf_path}")

    p.connect(p.GUI)
    p.setAdditionalSearchPath(pybullet_data.getDataPath())
    setup_scene()
    img_counter = 0
    target_images = 1000
    print("Starting improved YOLO data collection.")
    print("Improvements: projected AABB labels, tube+cap whole-object boxes, pose/lighting/colour randomisation.")

    try:
        while img_counter < target_images:
            if img_counter % 100 == 0:
                setup_scene()

            class_id = np.random.randint(0, len(CLASS_NAMES))
            base_id, cap_id, constraint_id = spawn_tube_assembly(class_id)
            for _ in range(np.random.randint(18, 42)):
                p.stepSimulation()

            view_matrix, proj_matrix = get_camera_matrices()
            annotation = get_projected_yolo_annotation([base_id, cap_id], class_id, view_matrix, proj_matrix)
            if annotation is None:
                remove_tube_assembly(base_id, cap_id, constraint_id)
                continue

            split = "train" if img_counter < int(target_images * 0.8) else "val"
            light_direction = np.random.uniform(-1.0, 1.0, size=3).tolist()
            shadow = int(np.random.random() > 0.35)
            img_data = p.getCameraImage(
                CAM_WIDTH,
                CAM_HEIGHT,
                view_matrix,
                proj_matrix,
                shadow=shadow,
                lightDirection=light_direction,
                renderer=p.ER_BULLET_HARDWARE_OPENGL,
            )
            rgb_array = np.reshape(img_data[2], (CAM_HEIGHT, CAM_WIDTH, 4))[:, :, :3]
            bgr_array = cv2.cvtColor(rgb_array, cv2.COLOR_RGB2BGR)
            image_path = dataset_path / "images" / split / f"tube_{img_counter}.jpg"
            label_path = dataset_path / "labels" / split / f"tube_{img_counter}.txt"
            cv2.imwrite(str(image_path), bgr_array)
            label_path.write_text(annotation + "\n", encoding="utf-8")

            remove_tube_assembly(base_id, cap_id, constraint_id)
            img_counter += 1
            if img_counter % 50 == 0:
                print(f"Captured {img_counter}/{target_images} images...")
    except KeyboardInterrupt:
        print("\nManual stop detected.")
    finally:
        p.disconnect()
        print(f"Dataset generation complete. Files saved in: {dataset_path}")


if __name__ == "__main__":
    run_data_collection()
