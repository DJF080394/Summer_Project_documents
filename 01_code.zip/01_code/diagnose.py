import os

BASE = os.path.dirname(os.path.abspath(__file__))
expected = [
    "meshes/ur5/visual/base.obj",
    "meshes/ur5/visual/shoulder.obj",
    "meshes/ur5/visual/upperarm.obj",
    "meshes/ur5/visual/forearm.obj",
    "meshes/ur5/visual/wrist1.obj",
    "meshes/ur5/visual/wrist2.obj",
    "meshes/ur5/visual/wrist3.obj",
    "meshes/robotiq_85/visual/robotiq_arg2f_85_base_link.dae",
    "meshes/robotiq_85/visual/robotiq_arg2f_85_outer_knuckle.dae",
]

print(f"Project root: {BASE}\n")
all_ok = True
for f in expected:
    full = os.path.join(BASE, f)
    status = "OK" if os.path.exists(full) else "MISSING"
    if status == "MISSING":
        all_ok = False
    print(f"  [{status}] {f}")

print()
if all_ok:
    print("All mesh files found!")
else:
    print("Some files are missing — copy the meshes folders from the new zip.")