"""Aggregate completed formal controller outputs without rerunning PyBullet."""

from __future__ import annotations

import csv
import math
from collections import defaultdict
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


BASE_DIR = Path(__file__).resolve().parent
FORMAL_DIR = BASE_DIR / "output" / "script_training"
SEEDS = (71, 83, 97)
CONTROLLERS = {
    "ppo": ("PPO final", "ppo", "ppo"),
    "sac": ("SAC final", "sac", "sac"),
    "timing_baseline": ("Timing baseline", "timing_baseline", "timing"),
}
CONDITIONS = ("deterministic", "randomised")
METRICS = (
    "mean_trigger_precision",
    "mean_false_actuation_rate",
    "mean_no_action_rate",
    "mean_decision_zone_no_actions",
    "mean_decision_zone_decisions",
    "mean_decision_zone_no_action_rate",
    "mean_firing_window_no_actions",
    "mean_firing_window_decisions",
    "mean_firing_window_no_action_rate",
    "mean_eligible_targets",
    "mean_successful_sorts",
    "mean_sorting_success_rate",
    "mean_misfires",
    "mean_misfire_rate",
    "mean_missed_targets",
    "mean_missed_target_rate",
    "mean_reward",
    "std_reward",
)


def mean(values: list[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def sample_sd(values: list[float]) -> float:
    if len(values) < 2:
        return 0.0
    centre = mean(values)
    return math.sqrt(sum((value - centre) ** 2 for value in values) / (len(values) - 1))


def read_one(path: Path) -> dict[str, str]:
    with path.open(newline="", encoding="utf-8") as handle:
        return next(csv.DictReader(handle))


def write_rows(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def aggregate_system_metrics() -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    fields = ["controller", "condition", "seed", *METRICS]
    for key, (label, folder, prefix) in CONTROLLERS.items():
        for condition in CONDITIONS:
            for seed in SEEDS:
                path = FORMAL_DIR / f"seed_{seed}" / folder / f"{prefix}_summary_{condition}_seed_{seed}.csv"
                if not path.exists():
                    raise FileNotFoundError(path)
                source = read_one(path)
                row: dict[str, object] = {"controller": label, "condition": condition, "seed": seed}
                for metric in METRICS:
                    row[metric] = source[metric]
                rows.append(row)
    write_rows(FORMAL_DIR / "system_metrics_by_seed.csv", rows, fields)
    return rows


def aggregate_by_controller(rows: list[dict[str, object]]) -> list[dict[str, object]]:
    grouped: defaultdict[tuple[str, str], list[dict[str, object]]] = defaultdict(list)
    for row in rows:
        grouped[(str(row["controller"]), str(row["condition"]))].append(row)
    fields = ["controller", "condition"]
    for metric in METRICS:
        fields += [f"{metric}_mean", f"{metric}_sd"]
    output: list[dict[str, object]] = []
    for (controller, condition), values in grouped.items():
        row: dict[str, object] = {"controller": controller, "condition": condition}
        for metric in METRICS:
            numbers = [float(value[metric]) for value in values]
            row[f"{metric}_mean"] = f"{mean(numbers):.6f}"
            row[f"{metric}_sd"] = f"{sample_sd(numbers):.6f}"
        output.append(row)
    write_rows(FORMAL_DIR / "system_metrics_summary.csv", output, fields)
    return output


def aggregate_type_metrics() -> None:
    groups: defaultdict[tuple[str, str, str], dict[str, float]] = defaultdict(
        lambda: defaultdict(float)
    )
    for key, (label, folder, prefix) in CONTROLLERS.items():
        for condition in CONDITIONS:
            for seed in SEEDS:
                path = FORMAL_DIR / f"seed_{seed}" / folder / f"{prefix}_type_summary_{condition}_seed_{seed}.csv"
                if not path.exists():
                    raise FileNotFoundError(path)
                with path.open(newline="", encoding="utf-8") as handle:
                    for source in csv.DictReader(handle):
                        group = groups[(label, condition, source["tube_type"])]
                        for field in ("spawned_targets", "eligible_targets", "successful_sorts", "wrong_triggers", "missed_targets"):
                            group[field] += float(source[field])
    rows: list[dict[str, object]] = []
    for (controller, condition, tube_type), values in sorted(groups.items()):
        eligible = values["eligible_targets"]
        successful = values["successful_sorts"]
        wrong = values["wrong_triggers"]
        missed = values["missed_targets"]
        rows.append(
            {
                "controller": controller,
                "condition": condition,
                "tube_type": tube_type,
                "spawned_targets": int(values["spawned_targets"]),
                "eligible_targets": int(eligible),
                "successful_sorts": int(successful),
                "wrong_triggers": int(wrong),
                "missed_targets": int(missed),
                "sorting_success_rate": f"{successful / eligible:.6f}" if eligible else "0.000000",
                "wrong_trigger_rate": f"{wrong / (successful + wrong):.6f}" if successful + wrong else "0.000000",
                "missed_target_rate": f"{missed / eligible:.6f}" if eligible else "0.000000",
            }
        )
    fields = list(rows[0]) if rows else []
    write_rows(FORMAL_DIR / "type_metrics_summary.csv", rows, fields)


def make_comparison_plot(summary_rows: list[dict[str, object]]) -> None:
    lookup = {(str(row["controller"]), str(row["condition"])): row for row in summary_rows}
    labels = ["Timing\nbaseline", "PPO", "SAC"]
    controllers = ["Timing baseline", "PPO final", "SAC final"]
    colours = ["#4C78A8", "#F58518", "#54A24B"]
    metrics = [
        ("mean_sorting_success_rate_mean", "Sorting success (%)"),
        ("mean_misfire_rate_mean", "Misfire rate (%)"),
        ("mean_missed_target_rate_mean", "Missed-target rate (%)"),
    ]
    fig, axes = plt.subplots(1, 3, figsize=(10.5, 3.2), constrained_layout=True)
    x = np.arange(len(controllers))
    width = 0.34
    for axis, (metric, title) in zip(axes, metrics):
        deterministic = [float(lookup[(controller, "deterministic")][metric]) * 100 for controller in controllers]
        randomised = [float(lookup[(controller, "randomised")][metric]) * 100 for controller in controllers]
        bars_a = axis.bar(x - width / 2, deterministic, width, label="Det.", color="#7A86E8")
        bars_b = axis.bar(x + width / 2, randomised, width, label="Rand.", color="#F27C83")
        axis.set_title(title, fontsize=10)
        axis.set_xticks(x, labels, fontsize=8)
        axis.grid(axis="y", color="#D9D9D9", linewidth=0.7)
        axis.set_axisbelow(True)
        axis.spines[["top", "right"]].set_visible(False)
        upper = max(deterministic + randomised + [1.0])
        axis.set_ylim(0, min(105, max(10, upper * 1.28)))
        axis.tick_params(labelsize=8)
        for bars in (bars_a, bars_b):
            axis.bar_label(bars, fmt="%.1f", fontsize=7, padding=2)
    axes[0].set_ylabel("Percentage (%)", fontsize=9)
    axes[0].legend(frameon=False, fontsize=8, loc="upper right")
    fig.savefig(FORMAL_DIR / "system_metrics_comparison.png", dpi=220, bbox_inches="tight")
    plt.close(fig)


def make_reward_plot() -> None:
    """Plot final evaluation reward distributions, clearly separate from training reward."""
    fig, axis = plt.subplots(figsize=(7.6, 3.6), constrained_layout=True)
    labels = ["Timing\nbaseline", "PPO", "SAC"]
    controllers = ["timing_baseline", "ppo", "sac"]
    display = {"timing_baseline": "Timing baseline", "ppo": "PPO final", "sac": "SAC final"}
    colours = ["#4C78A8", "#F58518", "#54A24B"]
    positions = np.arange(3)
    values: list[list[float]] = []
    for key in controllers:
        rewards: list[float] = []
        folder = CONTROLLERS[key][1]
        prefix = CONTROLLERS[key][2]
        for seed in SEEDS:
            for condition in CONDITIONS:
                path = FORMAL_DIR / f"seed_{seed}" / folder / f"{prefix}_episode_results_{condition}_seed_{seed}.csv"
                with path.open(newline="", encoding="utf-8") as handle:
                    rewards += [float(row["total_reward"]) for row in csv.DictReader(handle)]
        values.append(rewards)
    axis.boxplot(values, positions=positions, widths=0.48, patch_artist=True,
                 boxprops={"facecolor": "white", "edgecolor": "#666666"},
                 medianprops={"color": "#222222", "linewidth": 1.2},
                 whiskerprops={"color": "#666666"}, capprops={"color": "#666666"},
                 flierprops={"marker": ".", "markersize": 3, "markeredgecolor": "#777777"})
    for position, reward_values, colour in zip(positions, values, colours):
        jitter = np.linspace(-0.11, 0.11, len(reward_values))
        axis.scatter(position + jitter, reward_values, s=5, color=colour, alpha=0.28, linewidths=0)
    axis.set_xticks(positions, labels)
    axis.set_ylabel("Evaluation episode reward")
    axis.set_title("Final evaluation reward distribution (60 episodes per controller)")
    axis.grid(axis="y", color="#D9D9D9", linewidth=0.7)
    axis.set_axisbelow(True)
    axis.spines[["top", "right"]].set_visible(False)
    fig.savefig(FORMAL_DIR / "evaluation_reward_distribution.png", dpi=220, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    rows = aggregate_system_metrics()
    summary_rows = aggregate_by_controller(rows)
    aggregate_type_metrics()
    make_comparison_plot(summary_rows)
    make_reward_plot()
    print("Wrote aggregate formal metrics and thesis-ready figures.")


if __name__ == "__main__":
    main()
