import argparse
import csv
import os
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import pybullet as p
import pybullet_data


BASE_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = BASE_DIR / "output" / "baseline_evaluation"
DECISION_ZONE_WINDOW = 1.2
FIRING_WINDOW = 0.5


TUBE_URDF_PATHS = [
    r".\urdfs\tubes\polypropene-tube-1.urdf",
    r".\urdfs\tubes\polypropene-tube-2.urdf",
    r".\urdfs\tubes\polypropene-centrifugal-1.urdf",
    r".\urdfs\tubes\polypropene-centrifugal-2.urdf",
    r".\urdfs\tubes\lysis-tube-1.urdf",
]
TUBE_TYPE_NAMES = [
    "Polypropene 1",
    "Polypropene 2",
    "Polypropene centrifugal 1",
    "Polypropene centrifugal 2",
    "Lysis",
]


@dataclass
class EpisodeResult:
    controller: str
    episode: int
    total_reward: float
    correct_commands: int
    wrong_commands: int
    no_actions: int
    total_decisions: int
    correct_triggers: int
    wrong_triggers: int
    false_actuations: int
    decision_zone_no_actions: int = 0
    decision_zone_decisions: int = 0
    firing_window_no_actions: int = 0
    firing_window_decisions: int = 0
    eligible_targets: int = 0
    successful_sorts: int = 0
    misfires: int = 0
    missed_targets: int = 0
    type_metrics: dict = field(default_factory=dict)

    @property
    def command_accuracy(self) -> float:
        if self.total_decisions == 0:
            return 0.0
        return self.correct_commands / self.total_decisions

    @property
    def wrong_command_rate(self) -> float:
        if self.total_decisions == 0:
            return 0.0
        return self.wrong_commands / self.total_decisions

    @property
    def no_action_rate(self) -> float:
        if self.total_decisions == 0:
            return 0.0
        return self.no_actions / self.total_decisions

    @property
    def decision_zone_no_action_rate(self) -> float:
        if self.decision_zone_decisions == 0:
            return 0.0
        return self.decision_zone_no_actions / self.decision_zone_decisions

    @property
    def firing_window_no_action_rate(self) -> float:
        if self.firing_window_decisions == 0:
            return 0.0
        return self.firing_window_no_actions / self.firing_window_decisions

    @property
    def trigger_precision(self) -> float:
        total_trigger_attempts = self.correct_triggers + self.wrong_triggers + self.false_actuations
        if total_trigger_attempts == 0:
            return 0.0
        return self.correct_triggers / total_trigger_attempts

    @property
    def false_actuation_rate(self) -> float:
        trigger_commands = self.correct_commands + self.wrong_commands
        if trigger_commands == 0:
            return 0.0
        return self.false_actuations / trigger_commands

    @property
    def sorting_success_rate(self) -> float:
        if self.eligible_targets == 0:
            return 0.0
        return self.successful_sorts / self.eligible_targets

    @property
    def misfire_rate(self) -> float:
        trigger_events = self.correct_triggers + self.wrong_triggers + self.false_actuations
        if trigger_events == 0:
            return 0.0
        return self.misfires / trigger_events

    @property
    def missed_target_rate(self) -> float:
        if self.eligible_targets == 0:
            return 0.0
        return self.missed_targets / self.eligible_targets


class BaselineConveyorSortingEnv:
    """Minimal PyBullet environment for evaluating non-learning sorting baselines."""

    def __init__(self, render=False, randomised=False, include_robot=True):
        self.CONVEYOR_2_URDF = r".\urdfs\conveyor_belt_with_hopper.urdf"
        self.CONVEYOR_3_URDF = r".\urdfs\conveyor_belt_shortened.urdf"
        self.CONVEYOR_4_URDF = r".\urdfs\conveyor_belt_project_2.urdf"
        self.AIR_JET_URDF = r".\urdfs\air_jet.urdf"
        self.BIN_URDF = r".\urdfs\bin.urdf"
        self.BIN_FUNNEL_URDF = r".\urdfs\bin_funnel.urdf"
        self.ur5_path = r".\urdfs\ur5_robotiq_85.urdf"
        self.TUBE_URDF_PATHS = TUBE_URDF_PATHS
        self.jet_positions = [2.8 * i - 5.5 for i in range(5)]
        self.physics_client = p.connect(p.GUI if render else p.DIRECT)
        p.setAdditionalSearchPath(pybullet_data.getDataPath())
        self.tubes = []
        self.step_counter = 0
        self.last_step_stats = {
            "correct_triggers": 0,
            "wrong_triggers": 0,
            "false_actuations": 0,
            "successful_sorts": 0,
            "missed_targets": 0,
            "misfires": 0,
        }
        self.type_metrics = {}
        self.randomised = randomised
        self.include_robot = include_robot

    def reset(self, seed=None):
        if seed is not None:
            np.random.seed(seed)
        p.resetSimulation()
        p.setGravity(0, 0, -9.81)
        p.loadURDF("plane.urdf")

        conveyor_id_2 = p.loadURDF(self.CONVEYOR_2_URDF, basePosition=[0, -14, 7], useFixedBase=True)
        p.changeVisualShape(conveyor_id_2, -1, rgbaColor=[0.627451, 0.627451, 0.627451, 1])
        conveyor_id_3 = p.loadURDF(
            self.CONVEYOR_3_URDF,
            basePosition=[4, 0.7, 4.2 * 0.9],
            useFixedBase=True,
            globalScaling=0.9,
        )
        p.changeVisualShape(conveyor_id_3, -1, rgbaColor=[0.627451, 0.627451, 0.627451, 1])
        conveyor_id_4 = p.loadURDF(self.CONVEYOR_4_URDF, basePosition=[0, 0.7, 11], useFixedBase=True)
        p.changeVisualShape(conveyor_id_4, -1, rgbaColor=[0.627451, 0.627451, 0.627451, 1])

        air_jet_ori = p.getQuaternionFromEuler([0, 0, 1.57])
        bin_ori = p.getQuaternionFromEuler([0, 0, 1.57])
        for y in self.jet_positions:
            air_jet = p.loadURDF(
                self.AIR_JET_URDF,
                basePosition=[-3.9, y, 12.6],
                baseOrientation=air_jet_ori,
                useFixedBase=True,
            )
            p.changeVisualShape(air_jet, -1, rgbaColor=[0.627451, 0.627451, 0.627451, 1])
            bin_funnel = p.loadURDF(
                self.BIN_FUNNEL_URDF,
                basePosition=[2.3, y, 8.5],
                baseOrientation=bin_ori,
                useFixedBase=True,
            )
            p.changeVisualShape(bin_funnel, -1, rgbaColor=[0.627451, 0.627451, 0.627451, 1])

        cyl_vis_id = p.createVisualShape(
            p.GEOM_CYLINDER,
            radius=0.8,
            length=2,
            rgbaColor=[0.627451, 0.627451, 0.627451, 1],
        )
        cyl_col_id = p.createCollisionShape(p.GEOM_CYLINDER, radius=0.8, height=2)
        p.createMultiBody(
            baseMass=0,
            baseCollisionShapeIndex=cyl_col_id,
            baseVisualShapeIndex=cyl_vis_id,
            basePosition=[4.8, 2.8 * 2 - 5.5, 1],
        )
        p.loadURDF(self.BIN_URDF, basePosition=[7.5, 2.8 * 2 - 5.5, 0], useFixedBase=True, globalScaling=0.8)
        if self.include_robot:
            p.loadURDF(self.ur5_path, [4.8, 2.8 * 2 - 5.5, 2], useFixedBase=True, globalScaling=6)

        self.tubes = []
        self.step_counter = 0
        self.type_metrics = {
            str(index): {
                "spawned_targets": 0,
                "eligible_targets": 0,
                "successful_sorts": 0,
                "wrong_triggers": 0,
                "missed_targets": 0,
            }
            for index in range(5)
        }
        self._spawn_tube()
        return self._get_obs(), {}

    def _spawn_tube(self):
        idx = np.random.randint(0, 5)
        start_ori = p.getQuaternionFromEuler([1.5708, 0, np.random.uniform(0, 6.28)])
        start_pos = [-2, -13, 11]
        if self.randomised:
            start_pos = [
                -2 + np.random.uniform(-0.25, 0.25),
                -13 + np.random.uniform(-0.35, 0.35),
                11 + np.random.uniform(-0.1, 0.1),
            ]

        t_id = p.loadURDF(self.TUBE_URDF_PATHS[idx], start_pos, start_ori)

        mass = 0.2
        friction = 2.0
        angular_damping = 0.9
        if self.randomised:
            mass = np.random.uniform(0.16, 0.26)
            friction = np.random.uniform(1.4, 2.6)
            angular_damping = np.random.uniform(0.6, 1.1)

        p.changeDynamics(t_id, -1, mass=mass, lateralFriction=friction, angularDamping=angular_damping)
        self.type_metrics[str(idx)]["spawned_targets"] += 1
        self.tubes.append(
            {
                "id": t_id,
                "type": idx,
                "fired": False,
                "eligible": False,
                "outcome": None,
            }
        )

    def _mark_eligible(self, tube):
        if tube.get("eligible", False):
            return
        tube["eligible"] = True
        self.type_metrics[str(tube["type"])]["eligible_targets"] += 1

    def _mark_missed(self, tube):
        if not tube.get("eligible", False) or tube.get("outcome") is not None:
            return
        tube["outcome"] = "missed"
        self.last_step_stats["missed_targets"] += 1
        self.type_metrics[str(tube["type"])]["missed_targets"] += 1

    def _get_obs(self):
        if not self.tubes:
            return np.zeros(2, dtype=np.float32)
        active_tube = max(self.tubes, key=lambda tube: p.getBasePositionAndOrientation(tube["id"])[0][0])
        pos, _ = p.getBasePositionAndOrientation(active_tube["id"])
        y_norm = pos[1] / 9.0
        type_norm = (active_tube["type"] - 2.0) / 2.0
        return np.array([y_norm, type_norm], dtype=np.float32)

    def _apply_jet_force(self, jet_index, triggered_this_step):
        target_jet_y = self.jet_positions[jet_index]
        trigger_events = []
        for tube in self.tubes:
            if tube.get("fired", False):
                continue
            pos, _ = p.getBasePositionAndOrientation(tube["id"])
            if abs(pos[1] - target_jet_y) < 0.5 and -5.0 < pos[0] < 0 and 12 < pos[2] < 12.5:
                self._mark_eligible(tube)
                p.resetBaseVelocity(tube["id"], linearVelocity=[2, 0, 1.5])
                if tube["id"] not in triggered_this_step:
                    triggered_this_step.add(tube["id"])
                    tube["fired"] = True
                    if jet_index == tube["type"]:
                        tube["outcome"] = "success"
                        self.type_metrics[str(tube["type"])]["successful_sorts"] += 1
                        trigger_events.append("correct")
                    else:
                        tube["outcome"] = "misfire"
                        self.type_metrics[str(tube["type"])]["wrong_triggers"] += 1
                        trigger_events.append("wrong")
        return trigger_events

    def step(self, action):
        reward = 0.0
        frame_skip = 60
        obs = self._get_obs()
        triggered_this_step = set()
        self.last_step_stats = {
            "correct_triggers": 0,
            "wrong_triggers": 0,
            "false_actuations": 0,
            "successful_sorts": 0,
            "missed_targets": 0,
            "misfires": 0,
        }

        for _ in range(frame_skip):
            self.step_counter += 1
            if action < 5:
                trigger_events = self._apply_jet_force(action, triggered_this_step)
                self.last_step_stats["correct_triggers"] += trigger_events.count("correct")
                self.last_step_stats["wrong_triggers"] += trigger_events.count("wrong")
            p.stepSimulation()

            for tube in self.tubes[:]:
                pos, _ = p.getBasePositionAndOrientation(tube["id"])
                if -13.5 < pos[1] < -7 and 3 < pos[2] < 13.9:
                    p.resetBaseVelocity(tube["id"], [0, 1.5, 0.5], [0, 0, 0])
                if -8.0 < pos[1] < 8.0 and 12 < pos[2] < 12.25 and -3 < pos[0] < -1:
                    belt_speed = np.random.uniform(1.7, 2.3) if self.randomised else 2.0
                    p.resetBaseVelocity(tube["id"], [0, belt_speed, 0], [0, 0, 0])
                if -3 < pos[0] < 3 and 0 < pos[2] < 10:
                    upright_ori = p.getQuaternionFromEuler([0, 0, 0])
                    p.resetBasePositionAndOrientation(tube["id"], [2, pos[1], pos[2]], upright_ori)
                    p.resetBaseVelocity(tube["id"], linearVelocity=[0, 0, -9.81], angularVelocity=[0, 0, 0])
                if -1.0 < pos[0] < 3.0 and -8.0 < pos[1] < 8.0 and 4 < pos[2] < 5.4:
                    p.resetBaseVelocity(tube["id"], [0, 1, 0], [0, 0, 0])
                if -8.0 < pos[1] < 8.0 and 12 < pos[2] < 12.25 and -3 < pos[0] < -1:
                    self._mark_eligible(tube)
                if tube.get("eligible", False) and tube.get("outcome") is None and pos[1] > 8.2:
                    self._mark_missed(tube)

            if self.step_counter % 500 == 0:
                self._spawn_tube()

        if action < 5 and not triggered_this_step:
            self.last_step_stats["false_actuations"] = 1
        self.last_step_stats["successful_sorts"] = self.last_step_stats["correct_triggers"]
        self.last_step_stats["misfires"] = (
            self.last_step_stats["wrong_triggers"]
            + self.last_step_stats["false_actuations"]
        )

        for tube in self.tubes[:]:
            pos, _ = p.getBasePositionAndOrientation(tube["id"])
            y_pos = pos[1]
            target_y = self.jet_positions[tube["type"]]
            dist = abs(y_pos - target_y)
            reward += 5 * (1 - dist / 10)
            if action < 5:
                if abs(y_pos - self.jet_positions[action]) < 0.5:
                    reward += 5 if action == tube["type"] else -0.1
                if abs(y_pos - self.jet_positions[action]) > 1.5:
                    reward -= 0.5

        terminated = self.step_counter > 4100
        if terminated:
            for tube in self.tubes:
                self._mark_missed(tube)
        return self._get_obs(), reward, terminated, False, {}

    def episode_metrics(self):
        for tube in self.tubes:
            self._mark_missed(tube)
        eligible_targets = sum(item["eligible_targets"] for item in self.type_metrics.values())
        successful_sorts = sum(item["successful_sorts"] for item in self.type_metrics.values())
        wrong_triggers = sum(item["wrong_triggers"] for item in self.type_metrics.values())
        missed_targets = sum(item["missed_targets"] for item in self.type_metrics.values())
        return {
            "eligible_targets": eligible_targets,
            "successful_sorts": successful_sorts,
            "wrong_triggers": wrong_triggers,
            "missed_targets": missed_targets,
            "type_metrics": {
                key: dict(value) for key, value in self.type_metrics.items()
            },
        }


def denormalise_tube_type(type_norm):
    tube_type = int(round(float(type_norm) * 2.0 + 2.0))
    return int(np.clip(tube_type, 0, 4))


def denormalise_y_position(y_norm):
    return float(y_norm) * 9.0


def random_policy(obs, env):
    return int(np.random.randint(0, 6))


def class_rule_policy(obs, env):
    return denormalise_tube_type(obs[1])


def timing_policy(obs, env, fire_window=0.5):
    tube_type = denormalise_tube_type(obs[1])
    y_pos = denormalise_y_position(obs[0])
    target_y = env.jet_positions[tube_type]
    if abs(y_pos - target_y) <= fire_window:
        return tube_type
    return 5


def is_in_decision_zone(obs, env, decision_window=DECISION_ZONE_WINDOW):
    """True when the active tube is close enough to its target jet for a sorting decision."""
    tube_type = denormalise_tube_type(obs[1])
    y_pos = denormalise_y_position(obs[0])
    target_y = env.jet_positions[tube_type]
    return abs(target_y - y_pos) <= decision_window


def is_in_firing_window(obs, env, fire_window=FIRING_WINDOW):
    """True when the active tube is inside the narrow jet firing window."""
    tube_type = denormalise_tube_type(obs[1])
    y_pos = denormalise_y_position(obs[0])
    target_y = env.jet_positions[tube_type]
    return abs(target_y - y_pos) <= fire_window


POLICIES = {
    "random": random_policy,
    "class_rule": class_rule_policy,
    "timing": timing_policy,
}


def classify_decision(action, obs):
    true_type = denormalise_tube_type(obs[1])
    if action == 5:
        return "no_action"
    if action == true_type:
        return "correct"
    return "wrong"


def evaluate_policy(controller_name, policy_fn, episodes, seed, randomised, render, include_robot=True):
    results = []
    env = BaselineConveyorSortingEnv(
        render=render,
        randomised=randomised,
        include_robot=include_robot,
    )

    for episode in range(episodes):
        np.random.seed(seed + episode)
        obs, _ = env.reset(seed=seed + episode)
        terminated = False
        truncated = False
        total_reward = 0.0
        correct_commands = 0
        wrong_commands = 0
        no_actions = 0
        total_decisions = 0
        decision_zone_no_actions = 0
        decision_zone_decisions = 0
        firing_window_no_actions = 0
        firing_window_decisions = 0
        correct_triggers = 0
        wrong_triggers = 0
        false_actuations = 0

        while not (terminated or truncated):
            action = int(policy_fn(obs, env))
            decision = classify_decision(action, obs)
            in_decision_zone = is_in_decision_zone(obs, env)
            in_firing_window = is_in_firing_window(obs, env)
            if decision == "correct":
                correct_commands += 1
            elif decision == "wrong":
                wrong_commands += 1
            else:
                no_actions += 1

            total_decisions += 1
            if in_decision_zone:
                decision_zone_decisions += 1
                if action == 5:
                    decision_zone_no_actions += 1
            if in_firing_window:
                firing_window_decisions += 1
                if action == 5:
                    firing_window_no_actions += 1
            obs, reward, terminated, truncated, _ = env.step(action)
            total_reward += float(reward)
            correct_triggers += env.last_step_stats["correct_triggers"]
            wrong_triggers += env.last_step_stats["wrong_triggers"]
            false_actuations += env.last_step_stats["false_actuations"]

        metrics = env.episode_metrics()
        misfires = wrong_triggers + false_actuations
        results.append(
            EpisodeResult(
                controller=controller_name,
                episode=episode,
                total_reward=total_reward,
                correct_commands=correct_commands,
                wrong_commands=wrong_commands,
                no_actions=no_actions,
                total_decisions=total_decisions,
                correct_triggers=correct_triggers,
                wrong_triggers=wrong_triggers,
                false_actuations=false_actuations,
                decision_zone_no_actions=decision_zone_no_actions,
                decision_zone_decisions=decision_zone_decisions,
                firing_window_no_actions=firing_window_no_actions,
                firing_window_decisions=firing_window_decisions,
                eligible_targets=metrics["eligible_targets"],
                successful_sorts=metrics["successful_sorts"],
                misfires=misfires,
                missed_targets=metrics["missed_targets"],
                type_metrics=metrics["type_metrics"],
            )
        )

    p.disconnect(env.physics_client)
    return results


def write_episode_csv(results, csv_path):
    with csv_path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(
            [
                "controller",
                "episode",
                "total_reward",
                "correct_commands",
                "wrong_commands",
                "no_actions",
                "total_decisions",
                "command_accuracy",
                "wrong_command_rate",
                "no_action_rate",
                "decision_zone_no_actions",
                "decision_zone_decisions",
                "decision_zone_no_action_rate",
                "firing_window_no_actions",
                "firing_window_decisions",
                "firing_window_no_action_rate",
                "correct_triggers",
                "wrong_triggers",
                "false_actuations",
                "trigger_precision",
                "false_actuation_rate",
                "eligible_targets",
                "successful_sorts",
                "sorting_success_rate",
                "misfires",
                "misfire_rate",
                "missed_targets",
                "missed_target_rate",
            ]
        )
        for result in results:
            writer.writerow(
                [
                    result.controller,
                    result.episode,
                    f"{result.total_reward:.3f}",
                    result.correct_commands,
                    result.wrong_commands,
                    result.no_actions,
                    result.total_decisions,
                    f"{result.command_accuracy:.4f}",
                    f"{result.wrong_command_rate:.4f}",
                    f"{result.no_action_rate:.4f}",
                    result.decision_zone_no_actions,
                    result.decision_zone_decisions,
                    f"{result.decision_zone_no_action_rate:.4f}",
                    result.firing_window_no_actions,
                    result.firing_window_decisions,
                    f"{result.firing_window_no_action_rate:.4f}",
                    result.correct_triggers,
                    result.wrong_triggers,
                    result.false_actuations,
                    f"{result.trigger_precision:.4f}",
                    f"{result.false_actuation_rate:.4f}",
                    result.eligible_targets,
                    result.successful_sorts,
                    f"{result.sorting_success_rate:.4f}",
                    result.misfires,
                    f"{result.misfire_rate:.4f}",
                    result.missed_targets,
                    f"{result.missed_target_rate:.4f}",
                ]
            )


def summarise_results(results):
    summary = {}
    for controller in sorted({result.controller for result in results}):
        controller_results = [result for result in results if result.controller == controller]
        summary[controller] = {
            "mean_reward": np.mean([result.total_reward for result in controller_results]),
            "std_reward": np.std([result.total_reward for result in controller_results]),
            "mean_command_accuracy": np.mean([result.command_accuracy for result in controller_results]),
            "mean_wrong_command_rate": np.mean([result.wrong_command_rate for result in controller_results]),
            "mean_no_action_rate": np.mean([result.no_action_rate for result in controller_results]),
            "mean_decision_zone_no_actions": np.mean([result.decision_zone_no_actions for result in controller_results]),
            "mean_decision_zone_decisions": np.mean([result.decision_zone_decisions for result in controller_results]),
            "mean_decision_zone_no_action_rate": np.mean([result.decision_zone_no_action_rate for result in controller_results]),
            "mean_firing_window_no_actions": np.mean([result.firing_window_no_actions for result in controller_results]),
            "mean_firing_window_decisions": np.mean([result.firing_window_decisions for result in controller_results]),
            "mean_firing_window_no_action_rate": np.mean([result.firing_window_no_action_rate for result in controller_results]),
            "mean_correct_triggers": np.mean([result.correct_triggers for result in controller_results]),
            "mean_wrong_triggers": np.mean([result.wrong_triggers for result in controller_results]),
            "mean_false_actuations": np.mean([result.false_actuations for result in controller_results]),
            "mean_trigger_precision": np.mean([result.trigger_precision for result in controller_results]),
            "mean_false_actuation_rate": np.mean([result.false_actuation_rate for result in controller_results]),
            "mean_eligible_targets": np.mean([result.eligible_targets for result in controller_results]),
            "mean_successful_sorts": np.mean([result.successful_sorts for result in controller_results]),
            "mean_sorting_success_rate": np.mean([result.sorting_success_rate for result in controller_results]),
            "mean_misfires": np.mean([result.misfires for result in controller_results]),
            "mean_misfire_rate": np.mean([result.misfire_rate for result in controller_results]),
            "mean_missed_targets": np.mean([result.missed_targets for result in controller_results]),
            "mean_missed_target_rate": np.mean([result.missed_target_rate for result in controller_results]),
        }
    return summary


def write_summary_csv(summary, csv_path):
    with csv_path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(
            [
                "controller",
                "mean_reward",
                "std_reward",
                "mean_command_accuracy",
                "mean_wrong_command_rate",
                "mean_no_action_rate",
                "mean_decision_zone_no_actions",
                "mean_decision_zone_decisions",
                "mean_decision_zone_no_action_rate",
                "mean_firing_window_no_actions",
                "mean_firing_window_decisions",
                "mean_firing_window_no_action_rate",
                "mean_correct_triggers",
                "mean_wrong_triggers",
                "mean_false_actuations",
                "mean_trigger_precision",
                "mean_false_actuation_rate",
                "mean_eligible_targets",
                "mean_successful_sorts",
                "mean_sorting_success_rate",
                "mean_misfires",
                "mean_misfire_rate",
                "mean_missed_targets",
                "mean_missed_target_rate",
            ]
        )
        for controller, values in summary.items():
            writer.writerow(
                [
                    controller,
                    f"{values['mean_reward']:.3f}",
                    f"{values['std_reward']:.3f}",
                    f"{values['mean_command_accuracy']:.4f}",
                    f"{values['mean_wrong_command_rate']:.4f}",
                    f"{values['mean_no_action_rate']:.4f}",
                    f"{values['mean_decision_zone_no_actions']:.3f}",
                    f"{values['mean_decision_zone_decisions']:.3f}",
                    f"{values['mean_decision_zone_no_action_rate']:.4f}",
                    f"{values['mean_firing_window_no_actions']:.3f}",
                    f"{values['mean_firing_window_decisions']:.3f}",
                    f"{values['mean_firing_window_no_action_rate']:.4f}",
                    f"{values['mean_correct_triggers']:.3f}",
                    f"{values['mean_wrong_triggers']:.3f}",
                    f"{values['mean_false_actuations']:.3f}",
                    f"{values['mean_trigger_precision']:.4f}",
                    f"{values['mean_false_actuation_rate']:.4f}",
                    f"{values['mean_eligible_targets']:.3f}",
                    f"{values['mean_successful_sorts']:.3f}",
                    f"{values['mean_sorting_success_rate']:.4f}",
                    f"{values['mean_misfires']:.3f}",
                    f"{values['mean_misfire_rate']:.4f}",
                    f"{values['mean_missed_targets']:.3f}",
                    f"{values['mean_missed_target_rate']:.4f}",
                ]
            )


def write_type_summary_csv(results, csv_path):
    """Write class-wise sorting outcomes using only targets that reached the jet zone."""
    aggregates = {}
    for result in results:
        for type_index, values in result.type_metrics.items():
            item = aggregates.setdefault(
                type_index,
                {
                    "spawned_targets": 0,
                    "eligible_targets": 0,
                    "successful_sorts": 0,
                    "wrong_triggers": 0,
                    "missed_targets": 0,
                },
            )
            for key in item:
                item[key] += int(values.get(key, 0))

    controller = results[0].controller if results else "unknown"
    with csv_path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(
            [
                "controller",
                "tube_type",
                "spawned_targets",
                "eligible_targets",
                "successful_sorts",
                "wrong_triggers",
                "missed_targets",
                "sorting_success_rate",
                "wrong_trigger_rate",
                "missed_target_rate",
            ]
        )
        for type_index in sorted(aggregates, key=int):
            values = aggregates[type_index]
            eligible = values["eligible_targets"]
            triggered = values["successful_sorts"] + values["wrong_triggers"]
            writer.writerow(
                [
                    controller,
                    TUBE_TYPE_NAMES[int(type_index)],
                    values["spawned_targets"],
                    eligible,
                    values["successful_sorts"],
                    values["wrong_triggers"],
                    values["missed_targets"],
                    f"{values['successful_sorts'] / eligible:.4f}" if eligible else "0.0000",
                    f"{values['wrong_triggers'] / triggered:.4f}" if triggered else "0.0000",
                    f"{values['missed_targets'] / eligible:.4f}" if eligible else "0.0000",
                ]
            )


def plot_summary(summary, output_path):
    controllers = list(summary.keys())
    accuracy = [summary[name]["mean_trigger_precision"] * 100.0 for name in controllers]
    wrong_rate = [summary[name]["mean_false_actuation_rate"] * 100.0 for name in controllers]
    no_action_rate = [summary[name]["mean_no_action_rate"] * 100.0 for name in controllers]
    svg_path = output_path.with_suffix(".svg")
    write_summary_svg(controllers, accuracy, wrong_rate, no_action_rate, svg_path)
    return svg_path


def write_summary_svg(controllers, accuracy, wrong_rate, no_action_rate, output_path):
    width = 1180
    height = 720
    margin_left = 190
    margin_right = 90
    chart_top = 145
    chart_width = width - margin_left - margin_right
    row_gap = 150
    bar_height = 22
    bar_gap = 14
    colors = ["#2f6fbb", "#c94f4f", "#6d9f45"]
    labels = ["Trigger precision", "False actuation rate", "No action"]
    series = [accuracy, wrong_rate, no_action_rate]
    condition = "randomised" if "randomised" in output_path.stem else "deterministic"

    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        '<rect width="100%" height="100%" fill="#ffffff"/>',
        '<style>text{font-family:Arial, Helvetica, sans-serif}.title{font-size:26px;font-weight:700}.subtitle{font-size:14px;fill:#555}.axis{font-size:12px;fill:#555}.label{font-size:15px;fill:#222;font-weight:700}.value{font-size:12px;fill:#222}.legend{font-size:13px;fill:#222}</style>',
        f'<text x="{width / 2}" y="38" text-anchor="middle" class="title">Baseline controller comparison</text>',
        f'<text x="{width / 2}" y="62" text-anchor="middle" class="subtitle">Condition: {condition}; values are mean percentages over 10 episodes</text>',
    ]

    legend_start_x = margin_left
    for index, label in enumerate(labels):
        legend_x = legend_start_x + index * 260
        parts.append(f'<rect x="{legend_x}" y="88" width="16" height="16" rx="2" fill="{colors[index]}"/>')
        parts.append(
            f'<text x="{legend_x + 24}" y="101" class="legend">{label}</text>'
        )

    axis_y = chart_top + len(controllers) * row_gap + 16
    for tick in range(0, 101, 20):
        x = margin_left + tick / 100 * chart_width
        parts.append(
            f'<line x1="{x:.1f}" y1="{chart_top - 14}" x2="{x:.1f}" y2="{axis_y}" stroke="#e5e7eb" stroke-width="1"/>'
        )
        parts.append(
            f'<text x="{x:.1f}" y="{axis_y + 22}" text-anchor="middle" class="axis">{tick}</text>'
        )

    parts.append(f'<line x1="{margin_left}" y1="{axis_y}" x2="{margin_left + chart_width}" y2="{axis_y}" stroke="#374151" stroke-width="1.2"/>')
    parts.append(f'<text x="{margin_left + chart_width / 2}" y="{axis_y + 48}" text-anchor="middle" class="axis">Metric value (%)</text>')

    for group_index, controller in enumerate(controllers):
        group_y = chart_top + group_index * row_gap
        parts.append(
            f'<text x="{margin_left - 24}" y="{group_y + 45}" text-anchor="end" class="label">{controller}</text>'
        )
        for series_index, values in enumerate(series):
            value = values[group_index]
            bar_y = group_y + series_index * (bar_height + bar_gap)
            bar_width_px = max(1.0, value / 100 * chart_width)
            parts.append(
                f'<rect x="{margin_left}" y="{bar_y}" width="{bar_width_px:.1f}" height="{bar_height}" rx="3" fill="{colors[series_index]}"/>'
            )
            value_x = margin_left + bar_width_px + 8
            anchor = "start"
            if value_x > width - margin_right - 45:
                value_x = margin_left + bar_width_px - 8
                anchor = "end"
            parts.append(
                f'<text x="{value_x:.1f}" y="{bar_y + 15}" text-anchor="{anchor}" class="value">{value:.1f}%</text>'
            )

    parts.append(
        f'<text x="{margin_left}" y="{height - 24}" class="subtitle">Note: a lower false actuation rate is better; timing control is conservative, so its no-action rate is high.</text>'
    )
    parts.append("</svg>")
    output_path.write_text("\n".join(parts), encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description="Evaluate rule-based and classical-control baselines.")
    parser.add_argument("--episodes", type=int, default=10)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--randomised", action="store_true")
    parser.add_argument("--render", action="store_true")
    args = parser.parse_args()

    os.chdir(BASE_DIR)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    condition_name = "randomised" if args.randomised else "deterministic"
    all_results = []
    for controller_name, policy_fn in POLICIES.items():
        print(f"Evaluating {controller_name} baseline under {condition_name} conditions...")
        all_results.extend(
            evaluate_policy(
                controller_name=controller_name,
                policy_fn=policy_fn,
                episodes=args.episodes,
                seed=args.seed,
                randomised=args.randomised,
                render=args.render,
            )
        )

    episode_csv = OUTPUT_DIR / f"baseline_episode_results_{condition_name}.csv"
    summary_csv = OUTPUT_DIR / f"baseline_summary_{condition_name}.csv"
    plot_path = OUTPUT_DIR / f"baseline_controller_comparison_{condition_name}.png"

    write_episode_csv(all_results, episode_csv)
    summary = summarise_results(all_results)
    write_summary_csv(summary, summary_csv)
    actual_plot_path = plot_summary(summary, plot_path)

    print("\nSummary:")
    for controller, values in summary.items():
        print(
            f"{controller:>10s}: "
            f"trigger_precision={values['mean_trigger_precision'] * 100:5.1f}% | "
            f"false_actuation={values['mean_false_actuation_rate'] * 100:5.1f}% | "
            f"no_action={values['mean_no_action_rate'] * 100:5.1f}% | "
            f"correct_triggers={values['mean_correct_triggers']:5.1f} | "
            f"reward={values['mean_reward']:8.1f}"
        )
    print(f"\nSaved episode results: {episode_csv}")
    print(f"Saved summary results: {summary_csv}")
    print(f"Saved comparison figure: {actual_plot_path}")


if __name__ == "__main__":
    main()
