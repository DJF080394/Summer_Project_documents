from pathlib import Path

import numpy as np
import pybullet as p
import pybullet_data
from PIL import Image, ImageDraw, ImageFont


BASE_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = BASE_DIR / "figures"
OUTPUT_DIR.mkdir(exist_ok=True)

CAM_WIDTH, CAM_HEIGHT = 640, 640
CLASS_NAMES = [
    "polypropene_tube_1",
    "polypropene_tube_2",
    "polypropene_centrifugal_1",
    "polypropene_centrifugal_2",
    "lysis_tube_1",
]
TUBE_BASES = [
    BASE_DIR / "urdfs" / "tubes" / "bases" / "polypropene-1-base.urdf",
    BASE_DIR / "urdfs" / "tubes" / "bases" / "polypropene-2-base.urdf",
    BASE_DIR / "urdfs" / "tubes" / "bases" / "polystyrene-1-base.urdf",
    BASE_DIR / "urdfs" / "tubes" / "bases" / "polystyrene-2-base.urdf",
    BASE_DIR / "urdfs" / "tubes" / "bases" / "lysis-base.urdf",
]
TUBE_CAPS = [
    BASE_DIR / "urdfs" / "tubes" / "caps" / "polypropene-1-cap.urdf",
    BASE_DIR / "urdfs" / "tubes" / "caps" / "polypropene-2-cap.urdf",
    BASE_DIR / "urdfs" / "tubes" / "caps" / "polystyrene-1-cap.urdf",
    BASE_DIR / "urdfs" / "tubes" / "caps" / "polystyrene-2-cap.urdf",
    BASE_DIR / "urdfs" / "tubes" / "caps" / "lysis-cap.urdf",
]


def random_rgba(base_colour, rng):
    jitter = rng.uniform(-0.10, 0.10, size=3)
    colour = np.clip(np.array(base_colour[:3]) + jitter, 0.15, 0.95)
    return [float(colour[0]), float(colour[1]), float(colour[2]), 1.0]


def project_world_to_pixel(world_pos, view_matrix, proj_matrix):
    view_mat_np = np.array(view_matrix).reshape(4, 4, order="F")
    proj_mat_np = np.array(proj_matrix).reshape(4, 4, order="F")
    world_point = np.array([world_pos[0], world_pos[1], world_pos[2], 1.0])
    clip_point = proj_mat_np @ (view_mat_np @ world_point)
    if abs(clip_point[3]) < 1e-8:
        return None
    ndc_point = clip_point[:3] / clip_point[3]
    x_px = (ndc_point[0] + 1.0) * 0.5 * CAM_WIDTH
    y_px = (1.0 - ndc_point[1]) * 0.5 * CAM_HEIGHT
    return np.array([x_px, y_px], dtype=np.float32)


def aabb_corners(body_id):
    min_point, max_point = p.getAABB(body_id)
    xs = [min_point[0], max_point[0]]
    ys = [min_point[1], max_point[1]]
    zs = [min_point[2], max_point[2]]
    return [[x, y, z] for x in xs for y in ys for z in zs]


def projected_box(body_ids, view_matrix, proj_matrix):
    points = []
    for body_id in body_ids:
        for corner in aabb_corners(body_id):
            pixel = project_world_to_pixel(corner, view_matrix, proj_matrix)
            if pixel is not None:
                points.append(pixel)
    points = np.array(points)
    x1 = float(np.clip(points[:, 0].min(), 0, CAM_WIDTH - 1))
    y1 = float(np.clip(points[:, 1].min(), 0, CAM_HEIGHT - 1))
    x2 = float(np.clip(points[:, 0].max(), 0, CAM_WIDTH - 1))
    y2 = float(np.clip(points[:, 1].max(), 0, CAM_HEIGHT - 1))
    return x1, y1, x2, y2


def spawn_tube_assembly(class_id, position, yaw, rng):
    orientation = p.getQuaternionFromEuler([
        rng.uniform(1.35, 1.75),
        rng.uniform(-0.16, 0.16),
        yaw,
    ])
    base_id = p.loadURDF(str(TUBE_BASES[class_id]), position, orientation)
    cap_pos, cap_ori = p.multiplyTransforms(position, orientation, [0, 0, 0.5], [0, 0, 0, 1])
    cap_id = p.loadURDF(str(TUBE_CAPS[class_id]), cap_pos, cap_ori)
    p.createConstraint(
        parentBodyUniqueId=base_id,
        parentLinkIndex=-1,
        childBodyUniqueId=cap_id,
        childLinkIndex=-1,
        jointType=p.JOINT_FIXED,
        jointAxis=[0, 0, 0],
        parentFramePosition=[0, 0, 0.5],
        childFramePosition=[0, 0, 0],
    )
    base_palette = [
        [0.72, 0.74, 0.78],
        [0.82, 0.80, 0.74],
        [0.62, 0.72, 0.86],
        [0.80, 0.68, 0.72],
        [0.70, 0.82, 0.76],
    ]
    cap_palette = [
        [0.18, 0.33, 0.86],
        [0.86, 0.22, 0.18],
        [0.30, 0.66, 0.28],
        [0.90, 0.72, 0.18],
        [0.50, 0.24, 0.74],
    ]
    p.changeVisualShape(base_id, -1, rgbaColor=random_rgba(base_palette[class_id], rng))
    p.changeVisualShape(cap_id, -1, rgbaColor=random_rgba(cap_palette[class_id], rng))
    return base_id, cap_id


def draw_box(draw, box, colour):
    x1, y1, x2, y2 = box
    draw.rectangle([x1, y1, x2, y2], outline=colour, width=4)


def get_font(size, bold=False):
    candidates = [
        "C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf",
        "C:/Windows/Fonts/calibrib.ttf" if bold else "C:/Windows/Fonts/calibri.ttf",
        "C:/Windows/Fonts/segoeuib.ttf" if bold else "C:/Windows/Fonts/segoeui.ttf",
    ]
    for path in candidates:
        if Path(path).exists():
            return ImageFont.truetype(path, size=size)
    return ImageFont.load_default()


def draw_legend(draw, labels, colours):
    title_font = get_font(17, bold=True)
    body_font = get_font(15)
    label_font = get_font(15)
    panel = [12, 492, 628, 628]
    draw.rectangle(panel, fill=(245, 245, 245), outline=(40, 40, 40), width=1)
    draw.text((24, 506), "Improved YOLO synthetic annotation", fill=(0, 0, 0), font=title_font)
    draw.text((24, 532), "Projected 3D AABB boxes cover the full tube and cap.", fill=(0, 0, 0), font=body_font)
    y = 562
    for label, colour in zip(labels, colours):
        draw.rectangle([24, y + 2, 42, y + 18], fill=colour, outline=(0, 0, 0))
        draw.text((52, y), label, fill=(0, 0, 0), font=label_font)
        y += 22


def main():
    rng = np.random.default_rng(20260710)
    p.connect(p.DIRECT)
    pybullet_data_path = Path(pybullet_data.getDataPath())
    p.setAdditionalSearchPath(str(pybullet_data_path))
    p.setAdditionalSearchPath(str(BASE_DIR))
    p.resetSimulation()
    p.setGravity(0, 0, -9.81)
    p.loadURDF(str(pybullet_data_path / "plane.urdf"))
    p.loadURDF(str(BASE_DIR / "urdfs" / "conveyor_belt_with_hopper.urdf"), basePosition=[0, -14, 7], useFixedBase=True)

    tube_specs = [
        (0, [-2.38, -13.45, 11.05], 0.45),
        (2, [-1.72, -12.82, 11.12], 2.05),
        (4, [-2.24, -12.24, 10.98], 4.15),
    ]
    assemblies = [
        (class_id, spawn_tube_assembly(class_id, pos, yaw, rng))
        for class_id, pos, yaw in tube_specs
    ]
    for _ in range(25):
        p.stepSimulation()

    view_matrix = p.computeViewMatrixFromYawPitchRoll(
        [-2.05, -13.15, 11.25],
        3.15,
        90,
        -86.5,
        0,
        2,
    )
    proj_matrix = p.computeProjectionMatrixFOV(62, 1.0, 0.1, 100.0)
    img_data = p.getCameraImage(
        CAM_WIDTH,
        CAM_HEIGHT,
        view_matrix,
        proj_matrix,
        shadow=1,
        lightDirection=[0.4, -0.6, 0.9],
        renderer=p.ER_BULLET_HARDWARE_OPENGL,
    )
    rgb = np.reshape(img_data[2], (CAM_HEIGHT, CAM_WIDTH, 4))[:, :, :3].astype(np.uint8)
    image = Image.fromarray(rgb)
    draw = ImageDraw.Draw(image)
    colours = [(255, 210, 0), (0, 220, 255), (125, 255, 90)]
    legend_labels = []
    for colour, (class_id, body_ids) in zip(colours, assemblies):
        box = projected_box(body_ids, view_matrix, proj_matrix)
        draw_box(draw, box, colour)
        legend_labels.append(f"{CLASS_NAMES[class_id]}: whole-object bounding box")
    draw_legend(draw, legend_labels, colours)
    output_path = OUTPUT_DIR / "yolo_improved_annotation_example.png"
    image.save(output_path)
    p.disconnect()
    print(output_path)


if __name__ == "__main__":
    main()
