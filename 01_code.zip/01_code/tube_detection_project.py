import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
import subprocess
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

def main_menu():
    while True:
        print("\n" + "="*30)
        print(" TUBE DETECTION PROJECT MENU")
        print("="*30)
        print("1. Generate New Dataset - Training")
        print("2. Run Training - YOLOv8 Command")
        print("3. Run Live Simulation - Detection")
        print("4. Train RL Agent - PPO")
        print("5. Train RL Agent - SAC")
        print("6. Exit")
        
        choice = input("\nSelect an option (1-6): ")

        if choice == '1':
            from object_deyection import run_data_collection
            run_data_collection()
        elif choice == '2':
            print("\nStarting YOLOv8 Training...")
            env = os.environ.copy()
            env["KMP_DUPLICATE_LIB_OK"] = "TRUE"
            improved_train_dir = BASE_DIR / "tube1_improved" / "images" / "train"
            has_improved_images = improved_train_dir.exists() and any(improved_train_dir.glob("*.jpg"))
            data_config = "data_improved.yaml" if has_improved_images else "data.yaml"
            print(f"Using YOLO data config: {data_config}")
            if data_config == "data.yaml":
                print("Improved dataset not found yet. Run option 1 and use the default tube1_improved name to train with the improved labels.")
            subprocess.run(
                f"yolo task=detect mode=train model=yolov8n.pt data={data_config} epochs=50 imgsz=640 batch=8 workers=0", 
                env=env, 
                cwd=BASE_DIR,
                shell=True)
            #os.system("set KMP_DUPLICATE_LIB_OK=TRUE && yolo task=detect mode=train model=yolov8n.pt data=data.yaml epochs=50 imgsz=640 batch=16 workers=0")
        elif choice == '3':
            subprocess.run([sys.executable, "sample_test.py"], cwd=BASE_DIR)
        elif choice == '4':
            print("\nStarting RL Training Loop...")
            subprocess.run([sys.executable, "rl_training_ppo.py"], cwd=BASE_DIR)
        elif choice == '5':
            print("\nStarting RL Training Loop...")
            subprocess.run([sys.executable, "rl_training_sac.py"], cwd=BASE_DIR)
        elif choice == '6':
            print("Exiting...")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main_menu()
