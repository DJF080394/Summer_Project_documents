"""Run formal PPO/SAC training with decision-zone no-action metrics.

The controller reward and environment dynamics are kept unchanged. The new
metrics redefine no-action over the jet decision zone and firing window so the
reported no-action rate no longer includes distant conveyor travel steps.
"""

from __future__ import annotations

import argparse
import csv
import os
from pathlib import Path

import numpy as np

from evaluate_baselines import (
    evaluate_policy,
    summarise_results,
    timing_policy,
    write_episode_csv as write_baseline_episode_csv,
    write_summary_csv,
    write_type_summary_csv,
)
from train_final_rl_controllers import (
    FinalRLConveyorSortingEnv,
    RewardHistoryCallback,
    build_model,
    evaluate_model,
    write_episode_csv as write_rl_episode_csv,
    write_reward_history,
)


BASE_DIR = Path(__file__).resolve().parent
DEFAULT_OUTPUT = BASE_DIR / "output" / "script_training_decision_zone"
ALGORITHMS = ("ppo", "sac")
CONDITIONS = ((False, "deterministic"), (True, "randomised"))


def write_aggregate_csv(output_dir: Path, rows: list[dict[str, object]]) -> None:
    fields = [
        "controller",
        "condition",
        "seed",
        "mean_reward",
        "std_reward",
        "mean_trigger_precision",
        "mean_false_actuation_rate",
        "mean_no_action_rate",
        "mean_decision_zone_no_actions",
        "mean_decision_zone_decisions",
        "mean_decision_zone_no_action_rate",
        "mean_firing_window_no_actions",
        "mean_firing_window_decisions",
        "mean_firing_window_no_action_rate",
        "mean_eligible_targets",
        "mean_successful_sorts",
        "mean_sorting_success_rate",
        "mean_misfires",
        "mean_misfire_rate",
        "mean_missed_targets",
        "mean_missed_target_rate",
    ]
    with (output_dir / "decision_zone_metrics_by_seed.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def mean(values: list[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def sample_sd(values: list[float]) -> float:
    if len(values) < 2:
        return 0.0
    centre = mean(values)
    return float(np.sqrt(sum((value - centre) ** 2 for value in values) / (len(values) - 1)))


def write_summary_by_controller(output_dir: Path, rows: list[dict[str, object]]) -> None:
    metric_fields = [field for field in rows[0] if field not in {"controller", "condition", "seed"}]
    grouped: dict[tuple[str, str], list[dict[str, object]]] = {}
    for row in rows:
        grouped.setdefault((str(row["controller"]), str(row["condition"])), []).append(row)

    fields = ["controller", "condition"]
    for metric in metric_fields:
        fields += [f"{metric}_mean", f"{metric}_sd"]

    with (output_dir / "decision_zone_metrics_summary.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for (controller, condition), items in sorted(grouped.items()):
            output: dict[str, object] = {"controller": controller, "condition": condition}
            for metric in metric_fields:
                values = [float(item[metric]) for item in items]
                output[f"{metric}_mean"] = f"{mean(values):.6f}"
                output[f"{metric}_sd"] = f"{sample_sd(values):.6f}"
            writer.writerow(output)


def run_algorithm(algorithm: str, seed: int, timesteps: int, episodes: int, output_dir: Path) -> list[dict[str, object]]:
    algorithm_dir = output_dir / f"seed_{seed}" / algorithm
    algorithm_dir.mkdir(parents=True, exist_ok=True)

    print(f"=== {algorithm.upper()} training: seed={seed}, timesteps={timesteps} ===", flush=True)
    train_env = FinalRLConveyorSortingEnv(algorithm=algorithm, randomised=True, render=False)
    model = build_model(algorithm, train_env, timesteps, seed)
    callback = RewardHistoryCallback()
    model.learn(total_timesteps=timesteps, callback=callback)
    model.save(algorithm_dir / f"{algorithm}_policy_{timesteps}_steps_seed_{seed}")
    write_reward_history(
        callback,
        algorithm_dir / f"{algorithm}_training_rewards_seed_{seed}.csv",
        algorithm_dir / f"{algorithm}_training_rewards_seed_{seed}.png",
    )
    train_env.close()

    aggregate_rows: list[dict[str, object]] = []
    for randomised, condition in CONDITIONS:
        results = evaluate_model(
            model=model,
            algorithm=algorithm,
            episodes=episodes,
            seed=seed,
            randomised=randomised,
            trace_csv=algorithm_dir / f"{algorithm}_action_trace_{condition}_seed_{seed}.csv",
            heatmap_path=algorithm_dir / f"{algorithm}_state_action_{condition}_seed_{seed}.png",
        )
        write_rl_episode_csv(results, algorithm_dir / f"{algorithm}_episode_results_{condition}_seed_{seed}.csv")
        write_summary_csv(summarise_results(results), algorithm_dir / f"{algorithm}_summary_{condition}_seed_{seed}.csv")
        write_type_summary_csv(results, algorithm_dir / f"{algorithm}_type_summary_{condition}_seed_{seed}.csv")
        values = summarise_results(results)[f"{algorithm.upper()} final"]
        aggregate_rows.append(
            {
                "controller": f"{algorithm.upper()} final",
                "condition": condition,
                "seed": seed,
                **values,
            }
        )
        print(
            f"{algorithm.upper()} {condition} seed {seed}: "
            f"trigger={values['mean_trigger_precision'] * 100:.2f}% | "
            f"false={values['mean_false_actuation_rate'] * 100:.2f}% | "
            f"overall_no_action={values['mean_no_action_rate'] * 100:.2f}% | "
            f"decision_zone_no_action={values['mean_decision_zone_no_action_rate'] * 100:.2f}% | "
            f"firing_window_no_action={values['mean_firing_window_no_action_rate'] * 100:.2f}% | "
            f"success={values['mean_sorting_success_rate'] * 100:.2f}%",
            flush=True,
        )
    return aggregate_rows


def run_baseline(seed: int, episodes: int, output_dir: Path) -> list[dict[str, object]]:
    baseline_dir = output_dir / f"seed_{seed}" / "timing_baseline"
    baseline_dir.mkdir(parents=True, exist_ok=True)
    aggregate_rows: list[dict[str, object]] = []
    for randomised, condition in CONDITIONS:
        results = evaluate_policy(
            "Timing baseline",
            timing_policy,
            episodes,
            seed,
            randomised,
            render=False,
            include_robot=False,
        )
        write_baseline_episode_csv(results, baseline_dir / f"timing_episode_results_{condition}_seed_{seed}.csv")
        write_summary_csv(summarise_results(results), baseline_dir / f"timing_summary_{condition}_seed_{seed}.csv")
        write_type_summary_csv(results, baseline_dir / f"timing_type_summary_{condition}_seed_{seed}.csv")
        values = summarise_results(results)["Timing baseline"]
        aggregate_rows.append(
            {
                "controller": "Timing baseline",
                "condition": condition,
                "seed": seed,
                **values,
            }
        )
        print(
            f"Baseline {condition} seed {seed}: "
            f"trigger={values['mean_trigger_precision'] * 100:.2f}% | "
            f"false={values['mean_false_actuation_rate'] * 100:.2f}% | "
            f"overall_no_action={values['mean_no_action_rate'] * 100:.2f}% | "
            f"decision_zone_no_action={values['mean_decision_zone_no_action_rate'] * 100:.2f}% | "
            f"firing_window_no_action={values['mean_firing_window_no_action_rate'] * 100:.2f}% | "
            f"success={values['mean_sorting_success_rate'] * 100:.2f}%",
            flush=True,
        )
    return aggregate_rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--timesteps", type=int, default=30000)
    parser.add_argument("--episodes", type=int, default=20)
    parser.add_argument("--seeds", nargs="+", type=int, default=[71, 83, 97])
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()

    os.chdir(BASE_DIR)
    output_dir = args.output_dir if args.output_dir.is_absolute() else BASE_DIR / args.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    aggregate_rows: list[dict[str, object]] = []
    for seed in args.seeds:
        for algorithm in ALGORITHMS:
            aggregate_rows.extend(run_algorithm(algorithm, seed, args.timesteps, args.episodes, output_dir))
        aggregate_rows.extend(run_baseline(seed, args.episodes, output_dir))

    write_aggregate_csv(output_dir, aggregate_rows)
    write_summary_by_controller(output_dir, aggregate_rows)
    print(f"Saved decision-zone formal outputs to {output_dir}", flush=True)


if __name__ == "__main__":
    main()
