import csv
from pathlib import Path

from evaluate_baselines import BASE_DIR, OUTPUT_DIR, write_summary_svg


def find_output_dir():
    candidates = [
        OUTPUT_DIR,
        BASE_DIR / "output of baseline" / "baseline_evaluation",
    ]
    for candidate in candidates:
        if (candidate / "baseline_summary_deterministic.csv").exists():
            return candidate
    raise FileNotFoundError("Could not find baseline_summary_deterministic.csv in known output folders.")


def read_summary(path):
    controllers = []
    trigger_precision = []
    false_actuation_rate = []
    no_action_rate = []

    with path.open(newline="", encoding="utf-8") as file:
        reader = csv.DictReader(file)
        for row in reader:
            controllers.append(row["controller"])
            trigger_precision.append(float(row["mean_trigger_precision"]) * 100.0)
            false_actuation_rate.append(float(row["mean_false_actuation_rate"]) * 100.0)
            no_action_rate.append(float(row["mean_no_action_rate"]) * 100.0)

    return controllers, trigger_precision, false_actuation_rate, no_action_rate


def redraw(output_dir, condition):
    summary_path = output_dir / f"baseline_summary_{condition}.csv"
    output_path = output_dir / f"baseline_controller_comparison_{condition}.svg"
    data = read_summary(summary_path)
    write_summary_svg(*data, output_path)
    return output_path


def main():
    output_dir = find_output_dir()
    outputs = [redraw(output_dir, "deterministic"), redraw(output_dir, "randomised")]
    print("Redrawn baseline figures:")
    for output in outputs:
        print(output)


if __name__ == "__main__":
    main()
