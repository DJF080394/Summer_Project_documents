"""Train and evaluate PPO using the project's final timing-aware environment."""

import argparse
import os
from pathlib import Path

from train_final_rl_controllers import (
    FinalRLConveyorSortingEnv,
    RewardHistoryCallback,
    build_model,
    evaluate_model,
    plot_training_comparison,
    write_reward_history,
    write_episode_csv,
)
from evaluate_baselines import summarise_results, write_summary_csv, write_type_summary_csv


BASE_DIR = Path(__file__).resolve().parent
DEFAULT_OUTPUT = BASE_DIR / "output" / "script_training" / "ppo"


def main():
    parser = argparse.ArgumentParser(description="Train the PPO sorting controller.")
    parser.add_argument("--timesteps", type=int, default=100000)
    parser.add_argument("--episodes", type=int, default=20)
    parser.add_argument("--seed", type=int, default=71)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()

    os.chdir(BASE_DIR)
    output_dir = args.output_dir if args.output_dir.is_absolute() else BASE_DIR / args.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    print(f"=== PPO training: {args.timesteps} timesteps, seed {args.seed} ===")
    train_env = FinalRLConveyorSortingEnv(algorithm="ppo", randomised=True, render=False)
    model = build_model("ppo", train_env, args.timesteps, args.seed)
    reward_callback = RewardHistoryCallback()
    model.learn(total_timesteps=args.timesteps, callback=reward_callback)
    model.save(output_dir / f"ppo_policy_{args.timesteps}_steps_seed_{args.seed}")
    write_reward_history(
        reward_callback,
        output_dir / f"ppo_training_rewards_seed_{args.seed}.csv",
        output_dir / f"ppo_training_rewards_seed_{args.seed}.png",
    )
    train_env.close()

    rows = []
    for randomised in (False, True):
        condition = "randomised" if randomised else "deterministic"
        results = evaluate_model(
            model=model,
            algorithm="ppo",
            episodes=args.episodes,
            seed=args.seed,
            randomised=randomised,
            trace_csv=output_dir / f"ppo_action_trace_{condition}_seed_{args.seed}.csv",
            heatmap_path=output_dir / f"ppo_state_action_{condition}_seed_{args.seed}.png",
        )
        write_episode_csv(results, output_dir / f"ppo_episode_results_{condition}_seed_{args.seed}.csv")
        write_type_summary_csv(
            results,
            output_dir / f"ppo_type_summary_{condition}_seed_{args.seed}.csv",
        )
        summary = summarise_results(results)
        write_summary_csv(summary, output_dir / f"ppo_summary_{condition}_seed_{args.seed}.csv")
        values = summary["PPO final"]
        row = {
            "controller": "PPO",
            "condition": condition,
            "trigger_precision": values["mean_trigger_precision"] * 100.0,
            "false_actuation": values["mean_false_actuation_rate"] * 100.0,
            "no_action": values["mean_no_action_rate"] * 100.0,
        }
        rows.append(row)
        print(
            f"PPO {condition}: precision={row['trigger_precision']:.2f}% | "
            f"false_actuation={row['false_actuation']:.2f}% | "
            f"no_action={row['no_action']:.2f}%"
        )

    plot_training_comparison(rows, output_dir / f"ppo_summary_seed_{args.seed}.png")
    print(f"Saved PPO outputs to {output_dir}")


if __name__ == "__main__":
    main()
